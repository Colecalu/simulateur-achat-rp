repo: Colecalu/simulateur-achat-rp
branch: main

## Last sync
date: 2026-09-11T08:01:08Z
commit: 25a9142ca432

### Updated in this project
- Dépôt lu : il ne contient aujourd'hui que `CLAUDE.md` (intention du projet, aucun code source).
- Logique métier reprise de `CLAUDE.md` : enveloppe budgétaire globale identique, surplus investi en bourse, flat tax éditable (défaut 31,4 %), frais de notaire ancien/neuf, patrimoine net immobilier.
- Contraintes techniques reprises : HTML/CSS/JS vanilla sans build, Chart.js via CDN, interface en français.
- Aucune UI existante à recréer : les UI kits de ce design system sont des propositions, pas des reproductions.

## Screen map
| Écran du projet | Fichiers du dépôt |
| --- | --- |
| ui_kits/web/Landing.jsx | (aucun — pas de code amont) |
| ui_kits/web/Simulateur.jsx | CLAUDE.md (règles de calcul et champs) |
| ui_kits/web/Resultats.jsx | CLAUDE.md (règles de calcul et champs) |
