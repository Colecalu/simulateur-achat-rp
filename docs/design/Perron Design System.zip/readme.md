# Acheter ou louer — Design System

Design system du simulateur **Acheter ou louer** : un comparateur financier qui met en regard, sur la durée choisie par l'utilisateur, l'achat d'une résidence principale et le fait de rester locataire.

## Contexte produit

Le produit compare deux trajectoires patrimoniales à partir d'une **enveloppe budgétaire mensuelle identique** (logement + épargne), répartie différemment de chaque côté :

- **Achat** — mensualité de crédit, assurance emprunteur, charges de copropriété, taxe foncière, entretien ; le reste de l'enveloppe est investi en bourse. Patrimoine net immobilier = valeur du bien − capital restant dû.
- **Location** — loyer indexé ; tout le reste de l'enveloppe est investi en bourse.

Règles reprises du dépôt source : rendement boursier saisi en **brut**, fiscalité de sortie **éditable** (défaut 31,4 %, flat tax compte-titres 2026), frais de notaire différenciés **ancien / neuf**, comparaison finale toujours **nette d'impôt des deux côtés**.

Deux surfaces sont prévues : un **site web public** et une **application mobile**.

### Sources fournies

- **Dépôt GitHub** : `Colecalu/simulateur-achat-rp` (branche `main`). Au moment de la lecture, il ne contient que `CLAUDE.md` — aucun code source, aucune UI. Ce fichier décrit l'intention du projet : HTML/CSS/JS vanilla sans build, Chart.js via CDN, back PHP + MySQL, hébergement OVH mutualisé, interface en français. Voir `github.md` à la racine.
- **Référence d'ambiance citée par le client** : https://www.alchie.fr/ — pour le « côté réconfortant et chaleureux ». Aucune reprise d'identité, de logo ou de composant : seule la direction chaude a été retenue.
- **Aucun logo, aucune police de marque, aucune maquette** n'ont été fournis.

Conséquence : ce design system est une **proposition originale**, pas une recréation. Les UI kits montrent à quoi le produit pourrait ressembler ; ils ne reproduisent aucune interface existante.

---

## Content fundamentals

**Langue** : français exclusivement, y compris les libellés techniques.

**Personne** : on s'adresse à l'utilisateur en **vous**. Le produit ne dit jamais « je » et ne se met pas en scène. Les possessifs sont assumés : « votre simulation », « votre enveloppe », « le bien que vous visez ».

**Ton** : posé, factuel, jamais commercial. Le produit explique un calcul, il ne vend pas une décision. Pas de superlatif, pas d'urgence, pas de promesse de gain.

- ✅ « Sur 12 ans, acheter vous laisse 38 400 € de plus. »
- ❌ « Découvrez enfin la vérité sur l'immobilier ! »

**Honnêteté sur l'incertitude** : chaque résultat s'accompagne de ce qui le fragilise. C'est un réflexe d'écriture, pas une mention légale reléguée en bas de page.

- « Personne ne connaît le rendement des marchés sur douze ans. Faites varier les hypothèses : c'est l'écart entre les scénarios qui est instructif, pas le chiffre unique. »

**Casse** : phrase capitalisée normalement. Pas de Title Case (c'est un anglicisme), pas de capitales sauf pour les surtitres (`--type-eyebrow`, 11 px, +0,09em) qui servent de repères de section : `VOTRE RÉSULTAT`, `ÉTAPE 2`, `CE QUI CHANGE TOUT`.

**Chiffres** : espace insécable pour les milliers (`320 000 €`), virgule décimale (`31,4 %`), unité toujours accolée et jamais abrégée en jargon, signe `+` explicite sur les écarts favorables, `−` (moins typographique) sur les défavorables.

**Libellés de champs** : un nom, pas une question. « Prix du bien », pas « Quel est le prix du bien ? ». L'aide sous le champ porte la précision : « Hors frais de notaire », « 0,8 % de la valeur par défaut ».

**Boutons** : verbe à l'infinitif ou impératif court — « Faire ma simulation », « Voir le résultat détaillé », « Enregistrer », « Repartir des valeurs par défaut ». Jamais « Cliquez ici », jamais « OK ».

**Vocabulaire** : les termes financiers sont utilisés tels quels (capital restant dû, plus-value, flat tax, IRL, patrimoine net) et expliqués dans une infobulle d'une phrase au premier usage. On ne simplifie pas le mot, on explique la notion.

**Emoji** : aucun, nulle part.

---

## Visual foundations

### Couleur

Palette chaude, sans aucun gris neutre. Trois familles portent tout :

- **Terre cuite** `--clay-500 #A8663F` — couleur de marque, boutons primaires, liens, trajectoire **achat**.
- **Olive** `--olive-500 #6E7F58` — contrepoint calme, trajectoire **location**, conseils.
- **Papier** `--paper-50 → --paper-300` — fonds. `#FBF7F0` pour la page, `#FFFDF9` pour les cartes. **Jamais de blanc pur.**

L'encre est un brun profond `--warm-700 #2A211B`, pas du noir. Les neutres intermédiaires sont tous réchauffés. Les couleurs sémantiques (vert `#4E7A54`, ocre `#C08A2E`, brique `#A8402F`) sont désaturées pour rester dans la même famille.

Le couple achat / location est **le seul code couleur de données** du produit : terre cuite contre olive, partout, sans exception. Aucun dégradé décoratif, aucun bleu-violet.

### Typographie

- **Instrument Serif** (display) — titres de page et d'accroche uniquement, regular et italique, jamais de gras. Interlettrage −0,02em, interligne 1,04.
- **Geist** (sans) — toute l'interface : libellés, corps, boutons, tableaux. 300 à 700.
- **Geist Mono** — documentation uniquement, jamais dans le produit.

Les chiffres sont **toujours** en tabulaires alignés (`font-variant-numeric: tabular-nums lining-nums`), y compris dans le corps de texte, pour que les colonnes de montants ne dansent pas.

### Fonds, textures, imagerie

Le fond par défaut est le papier `--paper-100`. Les sections alternent papier / papier creux (`--paper-200`) — **deux valeurs de fond par page au maximum**.

Les grandes surfaces colorées (bandeau terre cuite, pied de page encre) portent un **grain** : `assets/grain.png`, tuile de 128 px, posée en calque à 28–34 % d'opacité. C'est le seul effet de texture du système. Pas de dégradé, pas de motif répété, pas d'illustration dessinée.

**Aucune imagerie photographique n'a été fournie.** Là où une photo serait attendue (accroche, page méthode), le kit met une carte de résultat réelle plutôt qu'un visuel de remplissage. Si des photos sont ajoutées un jour : lumière chaude, intérieurs habités, grain léger — jamais de rendu 3D ni de banque d'images froide.

### Cartes, bordures, ombres

La carte est l'unité de base : fond `--surface-card`, filet 1 px `--border-default` (un neutre chaud, pas un gris), rayon **20 px**, padding 24–28 px, ombre `--shadow-2`.

Les ombres sont **longues, très diffuses et teintées brun** — `0 1px 2px rgba(58,40,26,.05), 0 6px 16px -10px rgba(58,40,26,.18)` — jamais du noir, jamais de halo dur. Trois niveaux : `--shadow-1` filets et listes, `--shadow-2` cartes et boutons, `--shadow-3` modales. Une seule ombre forte par écran.

Une ombre interne discrète (`--shadow-inset-field`) creuse les champs de saisie : le papier est en relief, la saisie est en creux.

Pas de carte à bordure colorée sur un seul côté. Une carte qui appartient à une trajectoire prend le **ton complet** (`tone="accent"` ou `tone="secondary"`), fond teinté compris.

### Rayons

6 / 10 / **12 champs et boutons** / 14 / **20 cartes** / **28 feuilles et modales** / 36 / pastille pleine. Les pastilles et badges sont toujours en rayon plein.

### Mouvement

Court et sobre : 160 ms pour les survols, 240 ms pour les ouvertures, 420 ms pour le remplissage des barres de comparaison, 640 ms pour l'apparition des chiffres de résultat. Courbe par défaut `cubic-bezier(.2,.6,.25,1)`.

**Aucun rebond, aucun effet élastique, aucun `scale` à l'apparition.** Les chiffres n'ont pas besoin d'être spectaculaires pour être lus. `prefers-reduced-motion` coupe tout.

### États

- **Survol** : la couleur descend d'un cran dans l'échelle (terre cuite 500 → 600), les surfaces papier montent d'un cran (`--paper-200`). Jamais de changement d'opacité.
- **Appui** : `translateY(1px)` — l'élément s'enfonce, il ne rétrécit pas. Seule exception : la poignée de curseur, qui passe à `scale(.94)`.
- **Focus** : filet terre cuite `--clay-400` + halo 3 px `--ring-focus`. Visible au clavier, toujours.
- **Désactivé** : opacité 0,42 et curseur `not-allowed`, sans changement de couleur.
- **Erreur** : filet brique sur le champ, message porté par le `Field` sous le champ — jamais dans une infobulle.

### Transparence et flou

Réservés à deux cas : l'en-tête collant (`rgba(251,247,240,.88)` + `blur(10px)`) et le voile de modale (`rgba(42,33,27,.42)` + `blur(3px)`). Partout ailleurs, les fonds sont opaques. Pas de dégradé de protection sur les images : le texte se pose sur une surface pleine ou sur du grain, pas sur une photo assombrie.

### Mise en page

Contenu centré, largeur maximale 1200 px, gouttières 40 px en bureau / 20 px en mobile. Largeur de lecture confortable 680 px pour les paragraphes. Respiration verticale entre sections : 96 px en bureau, 56 px en mobile.

Un seul élément fixe : l'en-tête collant. Sur le simulateur, le récapitulatif d'enveloppe est `sticky` à 96 px du haut — il doit rester visible pendant la saisie, c'est la contrainte centrale du produit.

Trois hauteurs de contrôles seulement : 36 / 44 / 54 px.

---

## Iconography

**Système** : [Lucide](https://lucide.dev) — trait 2 px, boîte 24×24, extrémités arrondies. Cohérent avec la typographie humaniste et le trait doux du reste du système. ⚠️ **Substitution assumée** : aucune icône n'a été fournie par le client ; Lucide a été choisi comme le plus proche de la direction chaude et arrondie. À remplacer si une bibliothèque maison existe.

**Format** : 50 SVG copiés dans `assets/icons/` depuis le dépôt `lucide-icons/lucide`. Pas de police d'icônes, pas de sprite, pas de PNG.

**Coloration** : le composant `Icon` applique le SVG en **masque CSS** et le remplit avec `currentColor` — l'icône hérite donc de la couleur de son texte. Ne jamais poser un SVG en `<img>` : il resterait noir.

**Tailles** : 14–16 px inline dans du texte, 20 px dans les boutons et les listes, 24 px pour les repères de section, 22 px dans une pastille de 44 px pour les blocs d'étape.

**Emoji** : jamais. **Caractères Unicode comme icônes** : jamais non plus, à deux exceptions typographiques — le moins `−` (U+2212) devant les montants négatifs et l'espace fine insécable `&#8239;` avant les points d'interrogation et d'exclamation.

**Ne jamais dessiner un SVG à la main.** Si un glyphe manque, déposer le fichier Lucide correspondant dans `assets/icons/`.

---

## Substitutions à valider

1. **Polices** — aucune police de marque fournie. **Instrument Serif** (display) et **Geist** / **Geist Mono** (interface) sont chargées depuis Google Fonts via `tokens/fonts.css`. Elles ne sont donc pas embarquées comme fichiers dans le projet : à remplacer par les binaires de la marque dès qu'ils existent.
2. **Icônes** — Lucide, voir ci-dessus.
3. **Logo** — aucun logo fourni. Le nom est composé en Instrument Serif avec « ou » en italique terre cuite (`guidelines/logotype.html`). **Aucun logo n'a été dessiné.**
4. **Nom du projet** — le projet s'appelle encore « Perron Design System » dans l'outil ; le nom de marque retenu est « Acheter ou louer ».

---

## Index des fichiers

### Racine
- `styles.css` — point d'entrée unique, uniquement des `@import`.
- `readme.md` — ce document.
- `SKILL.md` — enveloppe Agent Skill pour réutilisation hors de cet outil.
- `github.md` — association au dépôt source et carte des écrans.
- `thumbnail.html` — vignette du design system.

### `tokens/`
`fonts.css` · `colors.css` · `typography.css` · `spacing.css` · `radius.css` · `elevation.css` · `motion.css` · `base.css` (reset et éléments de base).

### `components/`

**core/** — `Icon`, `Button`, `IconButton`, `Card`, `Badge`, `Callout`
**forms/** — `Field`, `TextInput`, `NumberField`, `Select`, `SegmentedControl`, `Slider`, `Checkbox`, `Switch`
**data/** — `StatTile`, `DeltaValue`, `ComparisonBar`, `Legend`, `DataTable`
**navigation/** — `Tabs`, `Stepper`
**feedback/** — `Dialog`, `Tooltip`

Chaque composant a un `.d.ts` (contrat de props) et un `.prompt.md` (quand l'utiliser, exemple, variantes). Chaque dossier a une carte HTML de démonstration.

Aucune source ne définissant d'inventaire de composants, l'ensemble a été composé à partir des besoins réels du simulateur. **Ajouts intentionnels** hors set standard : `Icon` (accès au jeu Lucide), `NumberField` (saisie avec unité — le champ le plus fréquent du produit), `StatTile`, `DeltaValue`, `ComparisonBar`, `Legend`, `DataTable` (le produit est un comparateur : ses primitives de données sont des primitives de marque), `Stepper` (parcours de saisie en quatre étapes).

### `guidelines/`
21 cartes de fondations — couleurs (terre cuite, olive, papier, neutres, sémantique, données, alias), typographie (display, corps, chiffres, mono, association), espacement (échelle, rythme, contrôles, rayons, élévations), marque (mouvement, grain, logotype, iconographie).

### `ui_kits/web/`
Site public : `Landing.jsx`, `Simulateur.jsx`, `Resultats.jsx`, `Chrome.jsx`, démonstration cliquable dans `index.html`. Voir `ui_kits/web/README.md`.

**Pas de kit mobile** : l'application mobile fait partie du produit mais n'a pas été retenue au cadrage. À produire sur demande.

### `assets/`
`icons/` (50 SVG Lucide) · `grain.png` (texture papier). Aucun logo, aucune photographie.
