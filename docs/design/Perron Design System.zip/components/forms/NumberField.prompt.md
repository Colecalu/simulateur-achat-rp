Saisie chiffree avec unite collee a droite : le controle le plus frequent du simulateur.

```jsx
<NumberField value="320 000" unit="€" />
<NumberField value="31,4" unit="%" size="s" />
```

Chiffres toujours en tabulaires, alignes a droite. Separateur de milliers = espace insecable, decimale = virgule.
