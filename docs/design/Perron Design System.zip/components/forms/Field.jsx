import React from 'react';
import { Icon } from '../core/Icon.jsx';

/** Enveloppe libelle + aide + erreur autour d'un controle de saisie. */
export function Field({ label, hint, error, htmlFor, info, children, style, ...rest }) {
  return (
    <div {...rest} style={{ display: 'grid', gap: 7, ...style }}>
      {label ? (
        <label htmlFor={htmlFor} style={{ display: 'flex', alignItems: 'center', gap: 6, font: 'var(--type-body)', fontSize: 'var(--fs-body-s)', fontWeight: 'var(--fw-medium)', color: 'var(--text-title)' }}>
          {label}
          {info ? <Icon name="info" size={14} color="var(--text-muted)" title={info} /> : null}
        </label>
      ) : null}
      {children}
      {error
        ? <span style={{ font: 'var(--type-caption)', color: 'var(--brick-500)' }}>{error}</span>
        : hint ? <span style={{ font: 'var(--type-caption)', fontWeight: 'var(--fw-regular)', color: 'var(--text-muted)' }}>{hint}</span> : null}
    </div>
  );
}
