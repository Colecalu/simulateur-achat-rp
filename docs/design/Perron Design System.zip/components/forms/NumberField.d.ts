import * as React from 'react';

/**
 * Saisie numerique avec unite.
 * @startingPoint section="Formulaires" subtitle="Champs du simulateur" viewport="700x300"
 */
export interface NumberFieldProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size' | 'value'> {
  value?: string | number;
  /** Unite affichee a droite : "EUR", "%", "ans", "EUR/mois". */
  unit?: string;
  size?: 's' | 'm' | 'l';
  align?: 'left' | 'right';
  invalid?: boolean;
}

export declare function NumberField(props: NumberFieldProps): JSX.Element;
