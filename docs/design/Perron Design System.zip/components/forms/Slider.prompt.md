Curseur pour les reglages continus : duree de detention, rendement, apport.

```jsx
<Slider label="Duree de detention" value={12} min={1} max={30} unit="ans" />
```

La piste se remplit en terre cuite jusqu'a la valeur. La valeur chiffree est toujours visible au-dessus, jamais seulement au survol. Le style de la poignee est fourni par la feuille `components/forms/slider-thumb.css` (importee par `styles.css`).
