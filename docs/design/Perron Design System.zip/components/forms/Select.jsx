import React from 'react';
import { Icon } from '../core/Icon.jsx';

const H = { s: 'var(--control-h-s)', m: 'var(--control-h-m)', l: 'var(--control-h-l)' };

/** Liste deroulante native habillee. */
export function Select({ options = [], value, onChange, size = 'm', disabled, invalid, style, ...rest }) {
  const [focus, setFocus] = React.useState(false);
  return (
    <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
      <select
        value={value} onChange={onChange} disabled={disabled}
        onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
        {...rest}
        style={{
          WebkitAppearance: 'none', appearance: 'none', width: '100%', height: H[size],
          padding: '0 42px 0 16px', font: 'var(--type-body)', color: 'var(--text-title)',
          background: disabled ? 'var(--paper-200)' : 'var(--surface-card)',
          border: '1px solid ' + (invalid ? 'var(--brick-500)' : focus ? 'var(--clay-400)' : 'var(--border-default)'),
          borderRadius: 'var(--radius-field)',
          boxShadow: focus ? 'var(--ring-focus)' : 'var(--shadow-inset-field)',
          outline: 'none', cursor: disabled ? 'not-allowed' : 'pointer', transition: 'var(--transition-control)',
          ...style,
        }}
      >
        {options.map(function (o) {
          const opt = typeof o === 'string' ? { value: o, label: o } : o;
          return <option key={opt.value} value={opt.value}>{opt.label}</option>;
        })}
      </select>
      <Icon name="chevron-down" size={18} color="var(--text-muted)" style={{ position: 'absolute', right: 14, pointerEvents: 'none' }} />
    </div>
  );
}
