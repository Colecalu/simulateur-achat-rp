import React from 'react';
import { Icon } from '../core/Icon.jsx';

/** Case a cocher avec libelle. */
export function Checkbox({ checked, onChange, label, description, disabled, style, ...rest }) {
  return (
    <label
      style={{
        display: 'flex', gap: 12, alignItems: 'flex-start', cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.5 : 1, ...style,
      }}
    >
      <input type="checkbox" checked={checked} onChange={onChange} disabled={disabled} {...rest}
        style={{ position: 'absolute', opacity: 0, width: 1, height: 1 }} />
      <span
        style={{
          display: 'flex', alignItems: 'center', justifyContent: 'center', flex: '0 0 auto',
          width: 22, height: 22, marginTop: 1, borderRadius: 'var(--radius-xs)',
          background: checked ? 'var(--clay-500)' : 'var(--surface-card)',
          border: '1px solid ' + (checked ? 'var(--clay-500)' : 'var(--border-strong)'),
          boxShadow: checked ? 'none' : 'var(--shadow-inset-field)',
          transition: 'var(--transition-control)',
        }}
      >
        {checked ? <Icon name="check" size={15} color="var(--text-inverse)" /> : null}
      </span>
      <span style={{ display: 'grid', gap: 2 }}>
        <span style={{ font: 'var(--type-body)', fontSize: 'var(--fs-body-s)', color: 'var(--text-title)' }}>{label}</span>
        {description ? <span style={{ font: 'var(--type-caption)', fontWeight: 'var(--fw-regular)', color: 'var(--text-muted)' }}>{description}</span> : null}
      </span>
    </label>
  );
}
