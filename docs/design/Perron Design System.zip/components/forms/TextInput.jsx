import React from 'react';
import { Icon } from '../core/Icon.jsx';

const H = { s: 'var(--control-h-s)', m: 'var(--control-h-m)', l: 'var(--control-h-l)' };

/** Champ texte a une ligne. */
export function TextInput({ size = 'm', icon, invalid, disabled, style, ...rest }) {
  const [focus, setFocus] = React.useState(false);
  return (
    <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
      {icon ? <Icon name={icon} size={18} color="var(--text-muted)" style={{ position: 'absolute', left: 14 }} /> : null}
      <input
        disabled={disabled}
        onFocus={() => setFocus(true)}
        onBlur={() => setFocus(false)}
        {...rest}
        style={{
          width: '100%', height: H[size], padding: icon ? '0 16px 0 42px' : '0 16px',
          font: 'var(--type-body)', color: 'var(--text-title)',
          background: disabled ? 'var(--paper-200)' : 'var(--surface-card)',
          border: '1px solid ' + (invalid ? 'var(--brick-500)' : focus ? 'var(--clay-400)' : 'var(--border-default)'),
          borderRadius: 'var(--radius-field)',
          boxShadow: focus ? 'var(--ring-focus)' : 'var(--shadow-inset-field)',
          outline: 'none', transition: 'var(--transition-control)',
          ...style,
        }}
      />
    </div>
  );
}
