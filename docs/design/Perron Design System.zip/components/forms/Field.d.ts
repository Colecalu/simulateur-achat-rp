import * as React from 'react';

export interface FieldProps extends React.HTMLAttributes<HTMLDivElement> {
  label?: React.ReactNode;
  /** Aide affichee sous le controle, masquee si `error` est present. */
  hint?: React.ReactNode;
  error?: React.ReactNode;
  htmlFor?: string;
  /** Texte d'infobulle native sur une icone d'information a cote du libelle. */
  info?: string;
}

export declare function Field(props: FieldProps): JSX.Element;
