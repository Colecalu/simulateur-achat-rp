import * as React from 'react';

export interface SliderProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'value' | 'type'> {
  value?: number;
  min?: number;
  max?: number;
  step?: number;
  /** Unite accolee a la valeur affichee ("ans", "%"). */
  unit?: string;
  showValue?: boolean;
  label?: React.ReactNode;
}

export declare function Slider(props: SliderProps): JSX.Element;
