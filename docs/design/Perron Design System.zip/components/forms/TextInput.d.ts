import * as React from 'react';

export interface TextInputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size'> {
  size?: 's' | 'm' | 'l';
  /** Nom d'icone Lucide placee a gauche dans le champ. */
  icon?: string;
  invalid?: boolean;
}

export declare function TextInput(props: TextInputProps): JSX.Element;
