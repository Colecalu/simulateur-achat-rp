import * as React from 'react';

export interface SegmentedOption { value: string; label: string; icon?: string }

export interface SegmentedControlProps extends React.HTMLAttributes<HTMLDivElement> {
  options?: Array<string | SegmentedOption>;
  value?: string;
  onChange?: (value: string) => void;
  size?: 's' | 'm' | 'l';
  fullWidth?: boolean;
}

export declare function SegmentedControl(props: SegmentedControlProps): JSX.Element;
