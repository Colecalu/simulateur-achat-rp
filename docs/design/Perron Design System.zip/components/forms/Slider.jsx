import React from 'react';

/** Curseur de reglage, avec valeur lisible au-dessus de la piste. */
export function Slider({ value = 0, min = 0, max = 100, step = 1, onChange, unit, showValue = true, label, style, ...rest }) {
  const pct = max === min ? 0 : ((value - min) / (max - min)) * 100;
  return (
    <div style={{ display: 'grid', gap: 8, ...style }}>
      {(label || showValue) && (
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: 12 }}>
          <span style={{ font: 'var(--type-body)', fontSize: 'var(--fs-body-s)', color: 'var(--text-body)' }}>{label}</span>
          {showValue ? (
            <span style={{ font: 'var(--type-body)', fontWeight: 'var(--fw-semibold)', color: 'var(--text-accent)', fontVariantNumeric: 'tabular-nums lining-nums' }}>
              {value}{unit ? '\u00A0' + unit : ''}
            </span>
          ) : null}
        </div>
      )}
      <input
        type="range" value={value} min={min} max={max} step={step} onChange={onChange}
        {...rest}
        style={{
          WebkitAppearance: 'none', appearance: 'none', width: '100%', height: 6, borderRadius: 'var(--radius-pill)',
          background: 'linear-gradient(to right, var(--clay-500) 0%, var(--clay-500) ' + pct + '%, var(--paper-300) ' + pct + '%, var(--paper-300) 100%)',
          outline: 'none', cursor: 'pointer',
        }}
      />
    </div>
  );
}
