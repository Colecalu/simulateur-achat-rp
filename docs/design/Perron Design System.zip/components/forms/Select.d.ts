import * as React from 'react';

export interface SelectOption { value: string; label: string }

export interface SelectProps extends Omit<React.SelectHTMLAttributes<HTMLSelectElement>, 'size'> {
  /** Chaines simples ou objets { value, label }. */
  options?: Array<string | SelectOption>;
  size?: 's' | 'm' | 'l';
  invalid?: boolean;
}

export declare function Select(props: SelectProps): JSX.Element;
