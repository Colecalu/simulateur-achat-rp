import React from 'react';

/** Interrupteur pour une bascule immediate. */
export function Switch({ checked, onChange, label, disabled, style, ...rest }) {
  return (
    <label style={{ display: 'inline-flex', alignItems: 'center', gap: 12, cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.5 : 1, ...style }}>
      <input type="checkbox" checked={checked} onChange={onChange} disabled={disabled} {...rest}
        style={{ position: 'absolute', opacity: 0, width: 1, height: 1 }} />
      <span
        style={{
          position: 'relative', width: 46, height: 27, borderRadius: 'var(--radius-pill)', flex: '0 0 auto',
          background: checked ? 'var(--clay-500)' : 'var(--warm-200)',
          transition: 'background-color var(--dur-base) var(--ease-standard)',
        }}
      >
        <span
          style={{
            position: 'absolute', top: 3, left: checked ? 22 : 3, width: 21, height: 21,
            borderRadius: 'var(--radius-pill)', background: 'var(--paper-50)', boxShadow: 'var(--shadow-1)',
            transition: 'left var(--dur-base) var(--ease-out-soft)',
          }}
        />
      </span>
      {label ? <span style={{ font: 'var(--type-body)', fontSize: 'var(--fs-body-s)', color: 'var(--text-title)' }}>{label}</span> : null}
    </label>
  );
}
