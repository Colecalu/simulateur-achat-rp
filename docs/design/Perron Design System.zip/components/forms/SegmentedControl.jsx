import React from 'react';
import { Icon } from '../core/Icon.jsx';

/** Choix exclusif entre 2 a 4 options courtes. */
export function SegmentedControl({ options = [], value, onChange, size = 'm', fullWidth = true, style, ...rest }) {
  const h = size === 's' ? 34 : size === 'l' ? 50 : 42;
  return (
    <div
      role="tablist" {...rest}
      style={{
        display: fullWidth ? 'grid' : 'inline-grid',
        gridTemplateColumns: 'repeat(' + options.length + ', 1fr)',
        gap: 3, padding: 3, background: 'var(--paper-200)',
        border: '1px solid var(--border-hairline)', borderRadius: 'var(--radius-control)', ...style,
      }}
    >
      {options.map(function (o) {
        const opt = typeof o === 'string' ? { value: o, label: o } : o;
        const active = opt.value === value;
        return (
          <button
            key={opt.value} type="button" role="tab" aria-selected={active}
            onClick={function () { if (onChange) onChange(opt.value); }}
            style={{
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
              height: h, padding: '0 14px', border: 'none', cursor: 'pointer',
              borderRadius: 'calc(var(--radius-control) - 3px)',
              background: active ? 'var(--surface-card)' : 'transparent',
              boxShadow: active ? 'var(--shadow-1)' : 'none',
              color: active ? 'var(--text-title)' : 'var(--text-muted)',
              font: 'var(--type-body)', fontSize: size === 's' ? 'var(--fs-body-s)' : 'var(--fs-body-m)',
              fontWeight: active ? 'var(--fw-semibold)' : 'var(--fw-medium)',
              transition: 'var(--transition-control)', whiteSpace: 'nowrap',
            }}
          >
            {opt.icon ? <Icon name={opt.icon} size={16} /> : null}
            {opt.label}
          </button>
        );
      })}
    </div>
  );
}
