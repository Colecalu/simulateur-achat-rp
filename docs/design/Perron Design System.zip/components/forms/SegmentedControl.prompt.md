Choix exclusif entre 2 et 4 options courtes — ancien/neuf, achat/location, mensuel/annuel.

```jsx
<SegmentedControl value="ancien" onChange={setType}
  options={[{ value: 'ancien', label: 'Ancien' }, { value: 'neuf', label: 'Neuf' }]} />
```

L'option active passe sur fond papier clair avec ombre 1 ; les autres restent en texte estompe.
