Champ texte standard, a placer dans un `Field`.

```jsx
<TextInput placeholder="Ville ou code postal" icon="map-pin" />
```

Focus : filet terre cuite + halo 3 px. Erreur : filet brique, message porte par le `Field`.
