Case a cocher pour les options independantes d'une simulation.

```jsx
<Checkbox checked={pno} onChange={...} label="Inclure l'assurance emprunteur"
  description="0,34 % du capital initial par an" />
```
