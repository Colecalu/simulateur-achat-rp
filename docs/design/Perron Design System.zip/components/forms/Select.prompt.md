Liste deroulante pour un choix parmi 4 options ou plus (en dessous, preferer SegmentedControl).

```jsx
<Select options={[{ value: 'cto', label: 'Compte-titres (31,4 %)' }, { value: 'pea', label: 'PEA (17,2 %)' }]} />
```
