Interrupteur : effet immediat sur l'affichage (pas de validation).

```jsx
<Switch checked={netImpot} onChange={...} label="Afficher net d'impot" />
```

Pour une option qui n'agit qu'apres validation du formulaire, utiliser Checkbox.
