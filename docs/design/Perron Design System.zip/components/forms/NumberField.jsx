import React from 'react';

const H = { s: 'var(--control-h-s)', m: 'var(--control-h-m)', l: 'var(--control-h-l)' };

/** Saisie numerique avec unite suffixee — le controle de base du simulateur. */
export function NumberField({ value, onChange, unit = '\u20AC', size = 'm', align = 'right', invalid, disabled, style, ...rest }) {
  const [focus, setFocus] = React.useState(false);
  return (
    <div
      style={{
        display: 'flex', alignItems: 'center', height: H[size],
        background: disabled ? 'var(--paper-200)' : 'var(--surface-card)',
        border: '1px solid ' + (invalid ? 'var(--brick-500)' : focus ? 'var(--clay-400)' : 'var(--border-default)'),
        borderRadius: 'var(--radius-field)',
        boxShadow: focus ? 'var(--ring-focus)' : 'var(--shadow-inset-field)',
        transition: 'var(--transition-control)', overflow: 'hidden', ...style,
      }}
    >
      <input
        inputMode="decimal" value={value} onChange={onChange} disabled={disabled}
        onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
        {...rest}
        style={{
          flex: 1, minWidth: 0, height: '100%', padding: '0 4px 0 16px', border: 'none', background: 'transparent',
          font: 'var(--type-body)', fontWeight: 'var(--fw-medium)', color: 'var(--text-title)',
          fontVariantNumeric: 'tabular-nums lining-nums', textAlign: align, outline: 'none',
        }}
      />
      <span style={{ padding: '0 16px 0 8px', font: 'var(--type-body)', fontSize: 'var(--fs-body-s)', color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>{unit}</span>
    </div>
  );
}
