import * as React from 'react';

export interface IconProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Nom du fichier dans assets/icons, sans extension. Ex. "house", "trending-up". */
  name: string;
  /** Cote du carre du glyphe, en px. */
  size?: number;
  /** Couleur du glyphe. Par defaut currentColor. */
  color?: string;
}

export declare function Icon(props: IconProps): JSX.Element;
