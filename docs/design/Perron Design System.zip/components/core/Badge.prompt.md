Pastille courte : etat, categorie, repere de scenario.

```jsx
<Badge tone="accent" icon="house">Achat</Badge>
<Badge tone="secondary" icon="key-round">Location</Badge>
```

Toujours en minuscules avec majuscule initiale, jamais en capitales. Pas de badge de plus de trois mots.
