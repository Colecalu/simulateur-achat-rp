import React from 'react';
import { Icon } from './Icon.jsx';

const SIZES = { s: 32, m: 40, l: 48 };

/** Bouton carre ne portant qu'une icone. */
export function IconButton({ icon, label, variant = 'secondary', size = 'm', disabled, style, ...rest }) {
  const [hover, setHover] = React.useState(false);
  const d = SIZES[size] || SIZES.m;
  const skin = variant === 'primary'
    ? { background: 'var(--clay-500)', color: 'var(--text-inverse)', border: '1px solid var(--clay-500)' }
    : variant === 'ghost'
      ? { background: hover ? 'var(--paper-200)' : 'transparent', color: 'var(--text-body)', border: '1px solid transparent' }
      : { background: hover ? 'var(--paper-200)' : 'var(--surface-card)', color: 'var(--text-title)', border: '1px solid var(--border-default)' };
  return (
    <button
      type="button" aria-label={label} title={label} disabled={disabled}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      {...rest}
      style={{
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        width: d, height: d, borderRadius: 'var(--radius-control)',
        cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.42 : 1,
        transition: 'var(--transition-control)',
        ...skin,
        ...(variant === 'primary' && hover ? { background: 'var(--clay-600)', borderColor: 'var(--clay-600)' } : null),
        ...style,
      }}
    >
      <Icon name={icon} size={size === 's' ? 16 : size === 'l' ? 22 : 19} />
    </button>
  );
}
