Bouton d'icone seule, pour les actions secondaires d'une barre ou d'une carte.

```jsx
<IconButton icon="share-2" label="Partager" />
<IconButton icon="refresh-ccw" label="Reinitialiser" variant="ghost" />
```

`label` est obligatoire : il sert d'`aria-label` et d'infobulle native.
