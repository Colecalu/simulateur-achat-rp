Conteneur standard : fond papier, filet chaud, rayon 20 px, ombre longue et tres diffuse.

```jsx
<Card title="Votre projet" action={<Button variant="ghost" size="s">Modifier</Button>}>
  ...
</Card>
```

`tone="accent"` pour la trajectoire achat, `tone="secondary"` pour la location, `tone="inverse"` pour un bloc de conclusion. Ne jamais empiler deux cartes elevation 3.
