import React from 'react';
import { Icon } from './Icon.jsx';

const TONES = {
  neutral: { background: 'var(--paper-200)', color: 'var(--text-body)' },
  accent: { background: 'var(--clay-100)', color: 'var(--clay-700)' },
  secondary: { background: 'var(--olive-100)', color: 'var(--olive-700)' },
  positive: { background: 'var(--green-100)', color: 'var(--green-700)' },
  warning: { background: 'var(--ochre-100)', color: 'var(--ochre-700)' },
  negative: { background: 'var(--brick-100)', color: 'var(--brick-700)' },
};

/** Pastille d'etat ou de categorie. */
export function Badge({ tone = 'neutral', icon, children, style, ...rest }) {
  return (
    <span
      {...rest}
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 6,
        padding: '5px 11px', borderRadius: 'var(--radius-pill)',
        font: 'var(--type-caption)', letterSpacing: '0.01em',
        ...TONES[tone], ...style,
      }}
    >
      {icon ? <Icon name={icon} size={14} /> : null}
      {children}
    </span>
  );
}
