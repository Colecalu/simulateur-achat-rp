import * as React from 'react';

export interface CalloutProps extends React.HTMLAttributes<HTMLDivElement> {
  tone?: 'info' | 'tip' | 'warning' | 'danger';
  /** Remplace l'icone par defaut du ton. */
  icon?: string;
  title?: React.ReactNode;
}

export declare function Callout(props: CalloutProps): JSX.Element;
