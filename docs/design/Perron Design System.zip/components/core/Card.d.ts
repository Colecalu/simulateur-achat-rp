import * as React from 'react';

/**
 * Carte de contenu.
 * @startingPoint section="Core" subtitle="Carte papier, tons et elevations" viewport="700x260"
 */
export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  tone?: 'paper' | 'sunken' | 'accent' | 'secondary' | 'inverse';
  /** 0 = aucun relief, 1 = filet, 2 = carte standard, 3 = surface flottante. */
  elevation?: 0 | 1 | 2 | 3;
  padding?: number | string;
  /** Titre optionnel rendu en haut de la carte. */
  title?: React.ReactNode;
  /** Element aligne a droite du titre (bouton, badge). */
  action?: React.ReactNode;
}

export declare function Card(props: CardProps): JSX.Element;
