import * as React from 'react';

/**
 * Bouton d'action du produit.
 * @startingPoint section="Core" subtitle="Boutons, variantes et tailles" viewport="700x220"
 */
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** primary = action principale (terre cuite pleine) ; secondary = action de soutien ; ghost = lien-action ; quiet = action discrete sur fond papier. */
  variant?: 'primary' | 'secondary' | 'ghost' | 'quiet';
  size?: 's' | 'm' | 'l';
  /** Nom d'icone Lucide affiche avant le libelle. */
  iconLeft?: string;
  /** Nom d'icone Lucide affiche apres le libelle. */
  iconRight?: string;
  fullWidth?: boolean;
}

export declare function Button(props: ButtonProps): JSX.Element;
