Encart d'explication ou d'avertissement, dans le flux de la page.

```jsx
<Callout tone="tip" title="Hypothese par defaut">
  Le surplus de chaque trajectoire est investi en bourse au meme rendement.
</Callout>
```

`info` pour une precision de methode, `tip` pour un conseil, `warning` pour une hypothese fragile, `danger` pour une saisie bloquante.
