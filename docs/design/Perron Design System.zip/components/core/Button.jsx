import React from 'react';
import { Icon } from './Icon.jsx';

const SIZES = {
  s: { height: 'var(--control-h-s)', padding: '0 16px', fontSize: 'var(--fs-body-s)', gap: 7, icon: 16 },
  m: { height: 'var(--control-h-m)', padding: '0 22px', fontSize: 'var(--fs-body-m)', gap: 9, icon: 18 },
  l: { height: 'var(--control-h-l)', padding: '0 30px', fontSize: 'var(--fs-body-l)', gap: 10, icon: 20 },
};

const VARIANTS = {
  primary: {
    background: 'var(--clay-500)', color: 'var(--text-inverse)',
    border: '1px solid var(--clay-500)', boxShadow: 'var(--shadow-2)',
    hover: { background: 'var(--clay-600)', borderColor: 'var(--clay-600)' },
  },
  secondary: {
    background: 'var(--surface-card)', color: 'var(--text-title)',
    border: '1px solid var(--border-default)', boxShadow: 'var(--shadow-1)',
    hover: { background: 'var(--paper-200)', borderColor: 'var(--border-strong)' },
  },
  ghost: {
    background: 'transparent', color: 'var(--text-accent)',
    border: '1px solid transparent', boxShadow: 'none',
    hover: { background: 'var(--clay-50)' },
  },
  quiet: {
    background: 'var(--paper-200)', color: 'var(--text-body)',
    border: '1px solid transparent', boxShadow: 'none',
    hover: { background: 'var(--paper-300)' },
  },
};

/** Bouton d'action. */
export function Button({
  variant = 'primary', size = 'm', iconLeft, iconRight, fullWidth,
  disabled, children, style, ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const s = SIZES[size] || SIZES.m;
  const v = VARIANTS[variant] || VARIANTS.primary;
  return (
    <button
      type="button"
      disabled={disabled}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => { setHover(false); setPress(false); }}
      onMouseDown={() => setPress(true)}
      onMouseUp={() => setPress(false)}
      {...rest}
      style={{
        display: fullWidth ? 'flex' : 'inline-flex', width: fullWidth ? '100%' : undefined,
        alignItems: 'center', justifyContent: 'center', gap: s.gap,
        height: s.height, padding: s.padding,
        font: 'var(--type-body)', fontSize: s.fontSize, fontWeight: 'var(--fw-medium)',
        borderRadius: 'var(--radius-control)', cursor: disabled ? 'not-allowed' : 'pointer',
        transition: 'var(--transition-control)', whiteSpace: 'nowrap',
        ...v, ...(hover && !disabled ? v.hover : null),
        transform: press && !disabled ? 'translateY(1px)' : 'none',
        opacity: disabled ? 0.42 : 1,
        ...style,
      }}
    >
      {iconLeft ? <Icon name={iconLeft} size={s.icon} /> : null}
      {children}
      {iconRight ? <Icon name={iconRight} size={s.icon} /> : null}
    </button>
  );
}
