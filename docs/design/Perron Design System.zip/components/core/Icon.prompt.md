Glyphe d'interface Lucide, colore par `currentColor` — l'unique source d'icones du produit.

```jsx
<Icon name="piggy-bank" size={20} />
<Icon name="trending-up" size={16} color="var(--data-positive)" />
```

Les fichiers vivent dans `assets/icons/`. Ajouter une icone = deposer le SVG Lucide correspondant dans ce dossier, jamais dessiner un SVG a la main. Tailles usuelles : 16 (inline dans du texte), 20 (boutons, listes), 24 (titres de carte), 32 (illustration de bloc).
