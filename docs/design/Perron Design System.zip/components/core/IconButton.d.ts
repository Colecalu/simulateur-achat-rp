import * as React from 'react';

export interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Nom d'icone Lucide (assets/icons). */
  icon: string;
  /** Libelle accessible, obligatoire. */
  label: string;
  variant?: 'primary' | 'secondary' | 'ghost';
  size?: 's' | 'm' | 'l';
}

export declare function IconButton(props: IconButtonProps): JSX.Element;
