import React from 'react';
import { Icon } from './Icon.jsx';

const TONES = {
  info: { background: 'var(--clay-50)', border: 'var(--clay-100)', icon: 'info', color: 'var(--clay-700)' },
  tip: { background: 'var(--olive-50)', border: 'var(--olive-100)', icon: 'lightbulb', color: 'var(--olive-700)' },
  warning: { background: 'var(--ochre-100)', border: '#EBD8AE', icon: 'circle-alert', color: 'var(--ochre-700)' },
  danger: { background: 'var(--brick-100)', border: '#EFC7BD', icon: 'circle-alert', color: 'var(--brick-700)' },
};

/** Encart explicatif inline. */
export function Callout({ tone = 'info', icon, title, children, style, ...rest }) {
  const t = TONES[tone] || TONES.info;
  return (
    <div
      {...rest}
      style={{
        display: 'flex', gap: 12, padding: '16px 18px',
        background: t.background, border: '1px solid ' + t.border,
        borderRadius: 'var(--radius-m)', ...style,
      }}
    >
      <Icon name={icon || t.icon} size={20} color={t.color} style={{ marginTop: 1 }} />
      <div style={{ display: 'grid', gap: 4 }}>
        {title ? <strong style={{ font: 'var(--type-body)', fontWeight: 'var(--fw-semibold)', color: t.color }}>{title}</strong> : null}
        <div style={{ font: 'var(--type-body)', fontSize: 'var(--fs-body-s)', color: 'var(--text-body)' }}>{children}</div>
      </div>
    </div>
  );
}
