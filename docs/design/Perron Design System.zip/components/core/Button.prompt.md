Bouton d'action : un seul `primary` visible par zone d'ecran.

```jsx
<Button variant="primary" size="l" iconRight="arrow-right">Lancer la simulation</Button>
<Button variant="secondary" iconLeft="download">Exporter</Button>
```

Variantes : `primary` (terre cuite pleine, ombre douce), `secondary` (papier + filet), `ghost` (texte terre cuite), `quiet` (pastille papier sombre). Tailles `s`/`m`/`l` = 36/44/54 px. Hover assombrit d'un cran, press descend de 1 px — jamais de scale.
