import * as React from 'react';

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  tone?: 'neutral' | 'accent' | 'secondary' | 'positive' | 'warning' | 'negative';
  /** Nom d'icone Lucide affiche avant le texte. */
  icon?: string;
}

export declare function Badge(props: BadgeProps): JSX.Element;
