import React from 'react';

const TONES = {
  paper: { background: 'var(--surface-card)', border: '1px solid var(--border-default)' },
  sunken: { background: 'var(--surface-sunken)', border: '1px solid var(--border-hairline)' },
  accent: { background: 'var(--clay-50)', border: '1px solid var(--clay-100)' },
  secondary: { background: 'var(--olive-50)', border: '1px solid var(--olive-100)' },
  inverse: { background: 'var(--surface-inverse)', border: '1px solid var(--surface-inverse)', color: 'var(--text-inverse)' },
};

/** Conteneur de contenu : papier, filet chaud, coins 20 px. */
export function Card({ tone = 'paper', elevation = 2, padding = 24, title, action, children, style, ...rest }) {
  return (
    <div
      {...rest}
      style={{
        borderRadius: 'var(--radius-card)',
        boxShadow: elevation === 0 ? 'none' : 'var(--shadow-' + elevation + ')',
        padding, ...TONES[tone], ...style,
      }}
    >
      {(title || action) && (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16, marginBottom: 16 }}>
          {title ? <h3 style={{ font: 'var(--type-title)', fontSize: 'var(--fs-title-s)', color: tone === 'inverse' ? 'var(--text-inverse)' : 'var(--text-title)' }}>{title}</h3> : <span />}
          {action}
        </div>
      )}
      {children}
    </div>
  );
}
