import React from 'react';

let cachedBase = null;
function resolveBase() {
  if (cachedBase) return cachedBase;
  if (typeof document !== 'undefined') {
    const s = Array.from(document.querySelectorAll('script[src]')).find(function (n) {
      return n.getAttribute('src').indexOf('_ds_bundle.js') !== -1;
    });
    if (s) {
      const src = s.getAttribute('src');
      cachedBase = src.slice(0, src.lastIndexOf('/') + 1) + 'assets/icons/';
      return cachedBase;
    }
  }
  cachedBase = 'assets/icons/';
  return cachedBase;
}

/** Glyphe Lucide colore via currentColor (masque CSS). */
export function Icon({ name, size = 20, strokeWidth, color = 'currentColor', style, ...rest }) {
  const url = resolveBase() + name + '.svg';
  return (
    <span
      aria-hidden="true"
      {...rest}
      style={{
        display: 'inline-block',
        flex: '0 0 auto',
        width: size,
        height: size,
        backgroundColor: color,
        WebkitMaskImage: 'url(' + url + ')',
        maskImage: 'url(' + url + ')',
        WebkitMaskRepeat: 'no-repeat',
        maskRepeat: 'no-repeat',
        WebkitMaskPosition: 'center',
        maskPosition: 'center',
        WebkitMaskSize: 'contain',
        maskSize: 'contain',
        opacity: strokeWidth === 'light' ? 0.7 : 1,
        ...style,
      }}
    />
  );
}
