Ecart entre les deux trajectoires, ou variation d'une valeur.

```jsx
<DeltaValue value="+38 400" unit="€" />
<DeltaValue value="-1 250" unit="€/an" size="s" />
```

Vert = favorable, brique = defavorable. Le signe est toujours ecrit, y compris le +.
