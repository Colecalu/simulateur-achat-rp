import * as React from 'react';

export interface DataColumn { key: string; label: string; align?: 'left' | 'right' | 'center'; emphasis?: boolean }

export interface DataTableProps extends React.HTMLAttributes<HTMLDivElement> {
  columns?: DataColumn[];
  /** Objets dont les cles correspondent aux `key` des colonnes ; valeurs deja formatees. */
  rows?: Array<Record<string, React.ReactNode>>;
}

export declare function DataTable(props: DataTableProps): JSX.Element;
