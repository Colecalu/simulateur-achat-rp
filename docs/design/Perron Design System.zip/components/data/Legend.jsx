import React from 'react';

/** Legende de graphique, pastilles rondes. */
export function Legend({ items = [], direction = 'row', style, ...rest }) {
  return (
    <div {...rest} style={{ display: 'flex', flexDirection: direction === 'column' ? 'column' : 'row', flexWrap: 'wrap', gap: direction === 'column' ? 8 : 18, ...style }}>
      {items.map(function (item) {
        return (
          <span key={item.label} style={{ display: 'inline-flex', alignItems: 'center', gap: 8, font: 'var(--type-body)', fontSize: 'var(--fs-body-s)', color: 'var(--text-body)' }}>
            <span style={{ width: 10, height: 10, borderRadius: '50%', background: item.color, flex: '0 0 auto' }} />
            {item.label}
            {item.value ? <strong style={{ fontWeight: 'var(--fw-semibold)', color: 'var(--text-title)', fontVariantNumeric: 'tabular-nums lining-nums' }}>{item.value}</strong> : null}
          </span>
        );
      })}
    </div>
  );
}
