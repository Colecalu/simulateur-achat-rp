Tableau annee par annee des resultats detailles.

```jsx
<DataTable
  columns={[{ key: 'an', label: 'Annee' }, { key: 'achat', label: 'Achat', align: 'right', emphasis: true }]}
  rows={[{ an: '2027', achat: '58 200 €' }]} />
```

Colonnes chiffrees toujours `align="right"`. Lignes paires teintees papier, jamais de bordures verticales.
