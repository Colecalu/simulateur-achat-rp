import * as React from 'react';

export interface LegendItem { label: string; color: string; value?: React.ReactNode }

export interface LegendProps extends React.HTMLAttributes<HTMLDivElement> {
  items?: LegendItem[];
  direction?: 'row' | 'column';
}

export declare function Legend(props: LegendProps): JSX.Element;
