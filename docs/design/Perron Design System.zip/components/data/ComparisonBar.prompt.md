Comparaison directe de deux a trois grandeurs sur une meme echelle.

```jsx
<ComparisonBar items={[{ label: 'Achat', value: 412800 }, { label: 'Location', value: 374400 }]}
  formatValue={(v) => v.toLocaleString('fr-FR') + ' €'} />
```

Utiliser pour un instantane a une date donnee ; pour l'evolution dans le temps, passer par un graphique Chart.js.
