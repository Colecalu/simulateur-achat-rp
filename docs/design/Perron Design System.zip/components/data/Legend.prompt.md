Legende accompagnant un graphique Chart.js (la legende native est desactivee au profit de celle-ci).

```jsx
<Legend items={[
  { label: 'Achat', color: 'var(--data-buy)', value: '412 800 €' },
  { label: 'Location', color: 'var(--data-rent)', value: '374 400 €' },
]} />
```
