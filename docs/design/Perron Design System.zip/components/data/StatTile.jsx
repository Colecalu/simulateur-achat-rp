import React from 'react';
import { Icon } from '../core/Icon.jsx';

const TONES = {
  neutral: { accent: 'var(--warm-300)', value: 'var(--text-title)' },
  buy: { accent: 'var(--data-buy)', value: 'var(--clay-600)' },
  rent: { accent: 'var(--data-rent)', value: 'var(--olive-600)' },
  positive: { accent: 'var(--data-positive)', value: 'var(--green-700)' },
  negative: { accent: 'var(--data-negative)', value: 'var(--brick-700)' },
};

/** Chiffre cle avec libelle, unite et note. */
export function StatTile({ label, value, unit, note, icon, tone = 'neutral', size = 'm', style, ...rest }) {
  const t = TONES[tone] || TONES.neutral;
  const fs = size === 'l' ? 'var(--fs-num-xl)' : size === 's' ? 'var(--fs-num-m)' : 'var(--fs-num-l)';
  return (
    <div
      {...rest}
      style={{
        display: 'grid', gap: 6, padding: '18px 20px',
        background: 'var(--surface-card)', border: '1px solid var(--border-default)',
        borderRadius: 'var(--radius-m)', boxShadow: 'var(--shadow-1)', ...style,
      }}
    >
      <span style={{ display: 'flex', alignItems: 'center', gap: 7, font: 'var(--type-caption)', color: 'var(--text-muted)' }}>
        {icon ? <Icon name={icon} size={15} color={t.accent} /> : null}
        {label}
      </span>
      <span style={{ display: 'flex', alignItems: 'baseline', gap: 6, fontFamily: 'var(--font-sans)', fontWeight: 'var(--fw-semibold)', fontSize: fs, lineHeight: 1.05, letterSpacing: 'var(--ls-display)', color: t.value, fontVariantNumeric: 'tabular-nums lining-nums' }}>
        {value}
        {unit ? <span style={{ fontSize: 'var(--fs-body-m)', fontWeight: 'var(--fw-medium)', color: 'var(--text-muted)' }}>{unit}</span> : null}
      </span>
      {note ? <span style={{ font: 'var(--type-caption)', fontWeight: 'var(--fw-regular)', color: 'var(--text-muted)' }}>{note}</span> : null}
    </div>
  );
}
