import * as React from 'react';

export interface ComparisonItem { label: string; value: number; color?: string }

export interface ComparisonBarProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Premiere entree = achat (terre cuite), seconde = location (olive), sauf `color` explicite. */
  items?: ComparisonItem[];
  /** Valeur de reference pour 100 % de la piste. Par defaut le maximum des items. */
  max?: number;
  /** Formatage de la valeur affichee. */
  formatValue?: (value: number) => string;
}

export declare function ComparisonBar(props: ComparisonBarProps): JSX.Element;
