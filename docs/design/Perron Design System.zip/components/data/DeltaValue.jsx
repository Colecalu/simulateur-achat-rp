import React from 'react';
import { Icon } from '../core/Icon.jsx';

/** Ecart chiffre, signe et colore. */
export function DeltaValue({ value, unit, direction, size = 'm', showIcon = true, style, ...rest }) {
  const dir = direction || (String(value).trim().charAt(0) === '-' ? 'down' : 'up');
  const color = dir === 'down' ? 'var(--data-negative)' : 'var(--data-positive)';
  return (
    <span
      {...rest}
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 5, color,
        fontFamily: 'var(--font-sans)', fontWeight: 'var(--fw-semibold)',
        fontSize: size === 'l' ? 'var(--fs-num-m)' : size === 's' ? 'var(--fs-body-s)' : 'var(--fs-body-l)',
        fontVariantNumeric: 'tabular-nums lining-nums', ...style,
      }}
    >
      {showIcon ? <Icon name={dir === 'down' ? 'trending-down' : 'trending-up'} size={size === 's' ? 14 : 17} /> : null}
      {value}{unit ? '\u00A0' + unit : ''}
    </span>
  );
}
