Chiffre cle isole : patrimoine net, mensualite, effort d'epargne.

```jsx
<StatTile label="Patrimoine net a 12 ans" value="412 800" unit="€" tone="buy"
  icon="house" note="Net d'impot, valeur du bien moins capital restant du" />
```

Le `value` est fourni deja formate. Ne jamais mettre plus de quatre StatTile cote a cote.
