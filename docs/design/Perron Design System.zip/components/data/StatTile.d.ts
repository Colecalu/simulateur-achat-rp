import * as React from 'react';

/**
 * Chiffre cle du simulateur.
 * @startingPoint section="Donnees" subtitle="Chiffres cles et comparaison" viewport="700x260"
 */
export interface StatTileProps extends React.HTMLAttributes<HTMLDivElement> {
  label: React.ReactNode;
  /** Valeur deja formatee en francais (espace insecable, virgule decimale). */
  value: React.ReactNode;
  unit?: React.ReactNode;
  note?: React.ReactNode;
  icon?: string;
  /** buy = trajectoire achat, rent = trajectoire location. */
  tone?: 'neutral' | 'buy' | 'rent' | 'positive' | 'negative';
  size?: 's' | 'm' | 'l';
}

export declare function StatTile(props: StatTileProps): JSX.Element;
