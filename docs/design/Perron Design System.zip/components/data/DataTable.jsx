import React from 'react';

/** Tableau de valeurs, chiffres en tabulaires alignes a droite. */
export function DataTable({ columns = [], rows = [], style, ...rest }) {
  return (
    <div {...rest} style={{ overflowX: 'auto', ...style }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', font: 'var(--type-body)', fontSize: 'var(--fs-body-s)' }}>
        <thead>
          <tr>
            {columns.map(function (c) {
              return (
                <th key={c.key} style={{
                  textAlign: c.align || 'left', padding: '10px 14px',
                  font: 'var(--type-eyebrow)', textTransform: 'uppercase', letterSpacing: 'var(--ls-caps)',
                  color: 'var(--text-muted)', borderBottom: '1px solid var(--border-default)', whiteSpace: 'nowrap',
                }}>{c.label}</th>
              );
            })}
          </tr>
        </thead>
        <tbody>
          {rows.map(function (r, i) {
            return (
              <tr key={i} style={{ background: i % 2 ? 'var(--paper-100)' : 'transparent' }}>
                {columns.map(function (c) {
                  return (
                    <td key={c.key} style={{
                      textAlign: c.align || 'left', padding: '12px 14px',
                      color: c.emphasis ? 'var(--text-title)' : 'var(--text-body)',
                      fontWeight: c.emphasis ? 'var(--fw-semibold)' : 'var(--fw-regular)',
                      fontVariantNumeric: c.align === 'right' ? 'tabular-nums lining-nums' : 'normal',
                      borderBottom: '1px solid var(--border-hairline)', whiteSpace: 'nowrap',
                    }}>{r[c.key]}</td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
