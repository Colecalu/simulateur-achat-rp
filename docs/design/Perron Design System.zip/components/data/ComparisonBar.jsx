import React from 'react';

/** Deux barres horizontales comparant achat et location. */
export function ComparisonBar({ items = [], max, formatValue, style, ...rest }) {
  const top = max || Math.max.apply(null, items.map(function (i) { return i.value; }).concat([1]));
  return (
    <div {...rest} style={{ display: 'grid', gap: 16, ...style }}>
      {items.map(function (item, i) {
        const color = item.color || (i === 0 ? 'var(--data-buy)' : 'var(--data-rent)');
        const pct = Math.max(2, (item.value / top) * 100);
        return (
          <div key={item.label} style={{ display: 'grid', gap: 7 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: 12 }}>
              <span style={{ font: 'var(--type-body)', fontSize: 'var(--fs-body-s)', color: 'var(--text-body)' }}>{item.label}</span>
              <span style={{ fontFamily: 'var(--font-sans)', fontWeight: 'var(--fw-semibold)', fontSize: 'var(--fs-body-l)', color: 'var(--text-title)', fontVariantNumeric: 'tabular-nums lining-nums' }}>
                {formatValue ? formatValue(item.value) : item.value}
              </span>
            </div>
            <div style={{ height: 14, borderRadius: 'var(--radius-pill)', background: 'var(--paper-300)', overflow: 'hidden' }}>
              <div style={{ width: pct + '%', height: '100%', background: color, borderRadius: 'var(--radius-pill)', transition: 'width var(--dur-slow) var(--ease-out-soft)' }} />
            </div>
          </div>
        );
      })}
    </div>
  );
}
