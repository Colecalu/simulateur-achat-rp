import * as React from 'react';

export interface DeltaValueProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Valeur formatee, signe compris. Ex. "+38 400". */
  value: React.ReactNode;
  unit?: string;
  /** Force le sens ; sinon deduit du signe de `value`. */
  direction?: 'up' | 'down';
  size?: 's' | 'm' | 'l';
  showIcon?: boolean;
}

export declare function DeltaValue(props: DeltaValueProps): JSX.Element;
