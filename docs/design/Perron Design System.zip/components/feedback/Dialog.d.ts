import * as React from 'react';

export interface DialogProps extends React.HTMLAttributes<HTMLDivElement> {
  open?: boolean;
  title?: React.ReactNode;
  description?: React.ReactNode;
  /** Boutons d'action, alignes a droite. */
  footer?: React.ReactNode;
  onClose?: () => void;
  width?: number;
}

export declare function Dialog(props: DialogProps): JSX.Element;
