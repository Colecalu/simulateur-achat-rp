import React from 'react';

/** Infobulle sombre au survol ou au focus. */
export function Tooltip({ content, placement = 'top', children, style, ...rest }) {
  const [open, setOpen] = React.useState(false);
  const pos = placement === 'bottom'
    ? { top: 'calc(100% + 8px)', left: '50%', transform: 'translateX(-50%)' }
    : { bottom: 'calc(100% + 8px)', left: '50%', transform: 'translateX(-50%)' };
  return (
    <span
      {...rest}
      onMouseEnter={() => setOpen(true)} onMouseLeave={() => setOpen(false)}
      onFocus={() => setOpen(true)} onBlur={() => setOpen(false)}
      style={{ position: 'relative', display: 'inline-flex', ...style }}
    >
      {children}
      <span
        role="tooltip"
        style={{
          position: 'absolute', ...pos, zIndex: 20, maxWidth: 260, width: 'max-content',
          padding: '9px 12px', borderRadius: 'var(--radius-s)',
          background: 'var(--surface-inverse)', color: 'var(--text-inverse)',
          font: 'var(--type-caption)', fontWeight: 'var(--fw-regular)', lineHeight: 1.45,
          boxShadow: 'var(--shadow-3)', pointerEvents: 'none',
          opacity: open ? 1 : 0,
          transition: 'opacity var(--dur-fast) var(--ease-standard)',
        }}
      >
        {content}
      </span>
    </span>
  );
}
