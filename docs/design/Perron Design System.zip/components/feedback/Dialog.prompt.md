Fenetre modale : enregistrer une simulation, expliquer une methode de calcul.

```jsx
<Dialog title="Enregistrer cette simulation" description="Vous la retrouverez dans votre espace."
  footer={<><Button variant="quiet">Annuler</Button><Button>Enregistrer</Button></>} onClose={...}>
  <Field label="Nom"><TextInput /></Field>
</Dialog>
```

Le voile est brun translucide avec un flou de 3 px. Le conteneur est positionne en `absolute` : le parent doit etre `position: relative`.
