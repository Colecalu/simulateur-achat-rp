import React from 'react';
import { IconButton } from '../core/IconButton.jsx';

/** Fenetre modale centree. */
export function Dialog({ open = true, title, description, footer, onClose, width = 520, children, style, ...rest }) {
  if (!open) return null;
  return (
    <div
      style={{
        position: 'absolute', inset: 0, zIndex: 50, display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: 24, background: 'rgba(42,33,27,.42)', backdropFilter: 'blur(3px)',
      }}
      onClick={onClose}
    >
      <div
        role="dialog" aria-modal="true" onClick={function (e) { e.stopPropagation(); }}
        {...rest}
        style={{
          width: '100%', maxWidth: width, background: 'var(--surface-card)',
          border: '1px solid var(--border-default)', borderRadius: 'var(--radius-sheet)',
          boxShadow: 'var(--shadow-3)', padding: 28, display: 'grid', gap: 18, ...style,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 16 }}>
          <div style={{ display: 'grid', gap: 6 }}>
            <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 'var(--fw-regular)', fontSize: 'var(--fs-title-l)', lineHeight: 'var(--lh-snug)', color: 'var(--text-title)' }}>{title}</h3>
            {description ? <p style={{ font: 'var(--type-body)', fontSize: 'var(--fs-body-s)', color: 'var(--text-body)' }}>{description}</p> : null}
          </div>
          {onClose ? <IconButton icon="x" label="Fermer" variant="ghost" size="s" onClick={onClose} /> : null}
        </div>
        {children}
        {footer ? <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>{footer}</div> : null}
      </div>
    </div>
  );
}
