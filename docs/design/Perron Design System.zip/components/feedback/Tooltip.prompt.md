Definition courte d'un terme financier, au survol d'une icone d'information.

```jsx
<Tooltip content="Part du prix qui ne vient pas du credit."><Icon name="info" size={15} /></Tooltip>
```

Une phrase, jamais de lien ni de bouton a l'interieur.
