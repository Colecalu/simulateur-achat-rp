import React from 'react';
import { Icon } from '../core/Icon.jsx';

/** Progression numerotee du parcours de saisie. */
export function Stepper({ steps = [], current = 0, onStepClick, style, ...rest }) {
  return (
    <ol {...rest} style={{ display: 'flex', alignItems: 'center', gap: 0, margin: 0, padding: 0, listStyle: 'none', ...style }}>
      {steps.map(function (label, i) {
        const done = i < current;
        const active = i === current;
        return (
          <li key={label} style={{ display: 'flex', alignItems: 'center', flex: i === steps.length - 1 ? '0 0 auto' : 1, minWidth: 0 }}>
            <button
              type="button"
              onClick={function () { if (onStepClick) onStepClick(i); }}
              style={{
                display: 'inline-flex', alignItems: 'center', gap: 10, background: 'none', border: 'none',
                padding: 0, cursor: onStepClick ? 'pointer' : 'default', minWidth: 0,
              }}
            >
              <span style={{
                display: 'flex', alignItems: 'center', justifyContent: 'center', flex: '0 0 auto',
                width: 30, height: 30, borderRadius: '50%',
                background: done ? 'var(--clay-500)' : active ? 'var(--surface-card)' : 'var(--paper-200)',
                border: '1px solid ' + (active ? 'var(--clay-500)' : done ? 'var(--clay-500)' : 'var(--border-default)'),
                color: done ? 'var(--text-inverse)' : active ? 'var(--text-accent)' : 'var(--text-muted)',
                font: 'var(--type-caption)', fontWeight: 'var(--fw-semibold)',
                transition: 'var(--transition-control)',
              }}>
                {done ? <Icon name="check" size={15} /> : i + 1}
              </span>
              <span style={{
                font: 'var(--type-body)', fontSize: 'var(--fs-body-s)',
                fontWeight: active ? 'var(--fw-semibold)' : 'var(--fw-regular)',
                color: active ? 'var(--text-title)' : 'var(--text-muted)',
                whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
              }}>{label}</span>
            </button>
            {i < steps.length - 1 ? <span style={{ flex: 1, height: 1, background: 'var(--border-default)', margin: '0 16px', minWidth: 16 }} /> : null}
          </li>
        );
      })}
    </ol>
  );
}
