Progression du formulaire de simulation.

```jsx
<Stepper steps={['Votre projet', 'Financement', 'Hypotheses', 'Resultat']} current={1} />
```

Etape faite = pastille terre cuite pleine avec une coche ; etape en cours = pastille papier cerclee ; a venir = pastille sourde.
