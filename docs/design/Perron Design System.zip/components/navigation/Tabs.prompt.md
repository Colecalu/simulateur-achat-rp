Onglets de niveau page : graphique, tableau, hypotheses.

```jsx
<Tabs value={vue} onChange={setVue} items={[
  { value: 'graph', label: 'Graphique', icon: 'chart-line' },
  { value: 'table', label: 'Annee par annee', icon: 'file-text' },
]} />
```
