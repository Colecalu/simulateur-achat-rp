import * as React from 'react';

export interface StepperProps extends React.HTMLAttributes<HTMLOListElement> {
  /** Libelles courts, 3 a 5 etapes. */
  steps?: string[];
  /** Index de l'etape en cours (0-based). */
  current?: number;
  onStepClick?: (index: number) => void;
}

export declare function Stepper(props: StepperProps): JSX.Element;
