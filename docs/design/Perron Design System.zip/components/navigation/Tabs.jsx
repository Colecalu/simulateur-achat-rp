import React from 'react';
import { Icon } from '../core/Icon.jsx';

/** Onglets soulignes pour changer de vue. */
export function Tabs({ items = [], value, onChange, style, ...rest }) {
  return (
    <div role="tablist" {...rest} style={{ display: 'flex', gap: 28, borderBottom: '1px solid var(--border-default)', ...style }}>
      {items.map(function (it) {
        const active = it.value === value;
        return (
          <button
            key={it.value} type="button" role="tab" aria-selected={active}
            onClick={function () { if (onChange) onChange(it.value); }}
            style={{
              display: 'inline-flex', alignItems: 'center', gap: 8, padding: '0 2px 14px',
              background: 'none', border: 'none', cursor: 'pointer',
              borderBottom: '2px solid ' + (active ? 'var(--clay-500)' : 'transparent'),
              marginBottom: -1, color: active ? 'var(--text-title)' : 'var(--text-muted)',
              font: 'var(--type-body)', fontWeight: active ? 'var(--fw-semibold)' : 'var(--fw-medium)',
              transition: 'var(--transition-control)',
            }}
          >
            {it.icon ? <Icon name={it.icon} size={17} /> : null}
            {it.label}
          </button>
        );
      })}
    </div>
  );
}
