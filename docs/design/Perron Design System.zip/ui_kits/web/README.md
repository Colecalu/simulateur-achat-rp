# UI kit — site web public

Recréation du site public du simulateur « Acheter ou louer ». Trois écrans, navigables depuis l'en-tête de `index.html`.

| Fichier | Écran |
| --- | --- |
| `Chrome.jsx` | En-tête collant, logotype composé, pied de page encre + grain |
| `Landing.jsx` | Accueil : accroche, carte de résultat exemple, trois étapes, méthode, bandeau terre cuite |
| `Simulateur.jsx` | Formulaire en trois cartes (bien, financement, hypothèses) + résumé d'enveloppe collant |
| `Resultats.jsx` | Chiffres clés, onglets graphique / tableau / hypothèses, graphique Chart.js, modale d'enregistrement |

Le graphique utilise Chart.js via CDN, conformément à la stack décrite dans le dépôt `Colecalu/simulateur-achat-rp` (HTML/CSS/JS vanilla, pas de build).

Les chiffres affichés sont illustratifs et cohérents entre eux (Lyon 3e, 320 000 €, ancien, enveloppe 1 850 €/mois, 12 ans) ; ils ne sortent pas du moteur de calcul réel.

**Non couvert** : l'application mobile. Le brief mentionne deux surfaces, mais seuls les écrans web ont été retenus lors du cadrage. À demander si le kit mobile est nécessaire.
