const { Button, IconButton, Icon } = window.PerronDesignSystem_49e698;

const NAV = [
  { key: 'landing', label: 'Le simulateur' },
  { key: 'simulateur', label: 'Faire une simulation' },
  { key: 'resultats', label: 'Exemple de résultat' },
];

function Logotype({ size = 22, inverse }) {
  return (
    <span style={{ fontFamily: 'var(--font-display)', fontSize: size, letterSpacing: 'var(--ls-display)', color: inverse ? 'var(--paper-50)' : 'var(--text-title)', whiteSpace: 'nowrap' }}>
      Acheter <i style={{ color: inverse ? 'var(--clay-200)' : 'var(--clay-500)' }}>ou</i> louer
    </span>
  );
}

function SiteHeader({ screen, onNavigate }) {
  return (
    <header style={{ position: 'sticky', top: 0, zIndex: 30, background: 'rgba(251,247,240,.88)', backdropFilter: 'blur(10px)', borderBottom: '1px solid var(--border-hairline)' }}>
      <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', padding: '0 var(--gutter-desktop)', height: 72, display: 'flex', alignItems: 'center', gap: 32 }}>
        <a href="#" onClick={(e) => { e.preventDefault(); onNavigate('landing'); }} style={{ textDecoration: 'none' }}><Logotype /></a>
        <nav style={{ display: 'flex', gap: 26, marginLeft: 12 }}>
          {NAV.map((n) => (
            <a key={n.key} href="#" onClick={(e) => { e.preventDefault(); onNavigate(n.key); }}
              style={{ textDecoration: 'none', font: 'var(--type-body)', fontSize: 'var(--fs-body-s)', fontWeight: screen === n.key ? 'var(--fw-semibold)' : 'var(--fw-regular)', color: screen === n.key ? 'var(--text-title)' : 'var(--text-body)' }}>
              {n.label}
            </a>
          ))}
        </nav>
        <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 12 }}>
          <IconButton icon="user-round" label="Mon espace" variant="ghost" size="s" />
          <Button size="s" iconRight="arrow-right" onClick={() => onNavigate('simulateur')}>Lancer une simulation</Button>
        </div>
      </div>
    </header>
  );
}

function SiteFooter() {
  const cols = [
    { t: 'Le produit', l: ['Simulateur', 'Méthode de calcul', 'Hypothèses par défaut', 'Enregistrer une simulation'] },
    { t: 'Comprendre', l: ['Frais de notaire ancien / neuf', 'Fiscalité des plus-values', 'Patrimoine net immobilier', 'Rendement brut et net'] },
    { t: 'À propos', l: ['Qui sommes-nous', 'Contact', 'Mentions légales', 'Confidentialité'] },
  ];
  return (
    <footer style={{ background: 'var(--surface-inverse)', color: 'var(--paper-200)', position: 'relative', overflow: 'hidden' }}>
      <span style={{ position: 'absolute', inset: 0, backgroundImage: 'url(../../assets/grain.png)', opacity: 0.3, pointerEvents: 'none' }} />
      <div style={{ position: 'relative', maxWidth: 'var(--container-max)', margin: '0 auto', padding: '56px var(--gutter-desktop) 32px', display: 'grid', gridTemplateColumns: '1.4fr repeat(3, 1fr)', gap: 40 }}>
        <div style={{ display: 'grid', gap: 12, alignContent: 'start' }}>
          <Logotype inverse />
          <p style={{ font: 'var(--type-body)', fontSize: 'var(--fs-body-s)', color: 'var(--warm-200)', maxWidth: 260 }}>
            Un simulateur qui compare l'achat de votre résidence principale au fait de rester locataire, à budget identique.
          </p>
        </div>
        {cols.map((c) => (
          <div key={c.t} style={{ display: 'grid', gap: 10, alignContent: 'start' }}>
            <span style={{ font: 'var(--type-eyebrow)', textTransform: 'uppercase', letterSpacing: 'var(--ls-caps)', color: 'var(--clay-200)' }}>{c.t}</span>
            {c.l.map((l) => <a key={l} href="#" onClick={(e) => e.preventDefault()} style={{ font: 'var(--type-body)', fontSize: 'var(--fs-body-s)', color: 'var(--paper-200)', textDecoration: 'none' }}>{l}</a>)}
          </div>
        ))}
      </div>
      <div style={{ position: 'relative', maxWidth: 'var(--container-max)', margin: '0 auto', padding: '20px var(--gutter-desktop) 40px', borderTop: '1px solid rgba(251,247,240,.14)', display: 'flex', justifyContent: 'space-between', font: 'var(--type-caption)', fontWeight: 'var(--fw-regular)', color: 'var(--warm-200)' }}>
        <span>© 2026 — Les résultats sont des projections, pas un conseil en investissement.</span>
        <span style={{ display: 'inline-flex', gap: 8, alignItems: 'center' }}><Icon name="lock" size={14} /> Aucune donnée revendue</span>
      </div>
    </footer>
  );
}

Object.assign(window, { SiteHeader, SiteFooter, Logotype });
