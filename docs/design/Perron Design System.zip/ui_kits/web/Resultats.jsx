const { Card, Button, IconButton, Badge, Tabs, StatTile, DeltaValue, ComparisonBar, Legend, DataTable, Callout, Dialog, Field, TextInput, Switch, Icon } = window.PerronDesignSystem_49e698;

const ROWS = [
  { an: '2027', achat: '58 200 €', loc: '61 900 €', ecart: '−3 700 €' },
  { an: '2029', achat: '118 400 €', loc: '124 300 €', ecart: '−5 900 €' },
  { an: '2031', achat: '186 900 €', loc: '188 100 €', ecart: '−1 200 €' },
  { an: '2033', achat: '248 700 €', loc: '243 500 €', ecart: '+5 200 €' },
  { an: '2035', achat: '318 200 €', loc: '302 800 €', ecart: '+15 400 €' },
  { an: '2038', achat: '412 800 €', loc: '374 400 €', ecart: '+38 400 €' },
];

function Chart({ height = 320 }) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!ref.current || !window.Chart) return;
    const years = Array.from({ length: 13 }, (_, i) => 2026 + i);
    const buy = [0, 22, 58, 88, 118, 152, 187, 217, 249, 282, 318, 364, 413].map((v) => v * 1000);
    const rent = [0, 31, 62, 93, 124, 156, 188, 216, 244, 273, 303, 338, 374].map((v) => v * 1000);
    const css = (n) => getComputedStyle(document.body).getPropertyValue(n).trim();
    const c = new window.Chart(ref.current, {
      type: 'line',
      data: {
        labels: years,
        datasets: [
          { label: 'Achat', data: buy, borderColor: css('--data-buy'), backgroundColor: 'rgba(168,102,63,.10)', fill: true, tension: 0.32, borderWidth: 2.5, pointRadius: 0 },
          { label: 'Location', data: rent, borderColor: css('--data-rent'), backgroundColor: 'rgba(110,127,88,.10)', fill: true, tension: 0.32, borderWidth: 2.5, pointRadius: 0, borderDash: [5, 4] },
        ],
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: { backgroundColor: css('--warm-700'), padding: 12, cornerRadius: 10, displayColors: false } },
        scales: {
          x: { grid: { display: false }, border: { color: css('--border-default') }, ticks: { color: css('--text-muted'), font: { family: 'Geist', size: 12 } } },
          y: { grid: { color: css('--border-hairline') }, border: { display: false }, ticks: { color: css('--text-muted'), font: { family: 'Geist', size: 12 }, callback: (v) => (v / 1000) + ' k€' } },
        },
      },
    });
    return () => c.destroy();
  }, []);
  return <div style={{ height }}><canvas ref={ref} /></div>;
}

function Resultats({ onNavigate }) {
  const [vue, setVue] = React.useState('graph');
  const [save, setSave] = React.useState(false);
  const [net, setNet] = React.useState(true);

  return (
    <main style={{ position: 'relative' }}>
      <section style={{ background: 'var(--surface-sunken)', borderBottom: '1px solid var(--border-hairline)' }}>
        <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', padding: '48px var(--gutter-desktop) 40px', display: 'grid', gap: 26 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 24, flexWrap: 'wrap' }}>
            <div style={{ display: 'grid', gap: 14, maxWidth: 720 }}>
              <Badge tone="accent" icon="map-pin">Lyon 3e · 320 000 € · ancien · 12 ans</Badge>
              <h1 style={{ fontSize: 'var(--fs-display-l)' }}>Sur 12 ans, acheter vous laisse <span style={{ color: 'var(--clay-500)' }}>38 400 €</span> de plus</h1>
              <p style={{ fontSize: 'var(--fs-body-l)', color: 'var(--text-body)' }}>
                À enveloppe identique de 1 850 € par mois, net d'impôt des deux côtés. L'achat passe devant la location à partir de la septième année.
              </p>
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <IconButton icon="share-2" label="Partager" />
              <IconButton icon="download" label="Télécharger en PDF" />
              <Button iconLeft="bookmark" onClick={() => setSave(true)}>Enregistrer</Button>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
            <StatTile label="Patrimoine net — achat" value="412 800" unit="€" tone="buy" icon="house" />
            <StatTile label="Patrimoine net — location" value="374 400" unit="€" tone="rent" icon="key-round" />
            <StatTile label="Écart final" value="+38 400" unit="€" tone="positive" icon="scale" />
            <StatTile label="Point de bascule" value="7,2" unit="ans" icon="clock" note="Avant cette date, louer est gagnant" />
          </div>
        </div>
      </section>

      <section style={{ maxWidth: 'var(--container-max)', margin: '0 auto', padding: '36px var(--gutter-desktop) 88px', display: 'grid', gridTemplateColumns: '1.6fr 1fr', gap: 28, alignItems: 'start' }}>
        <Card padding={26}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 20, marginBottom: 20 }}>
            <Tabs value={vue} onChange={setVue} items={[{ value: 'graph', label: 'Graphique', icon: 'chart-line' }, { value: 'table', label: 'Année par année', icon: 'file-text' }, { value: 'hyp', label: 'Hypothèses', icon: 'sliders-horizontal' }]} style={{ flex: 1 }} />
            <Switch checked={net} onChange={() => setNet(!net)} label="Net d'impôt" />
          </div>

          {vue === 'graph' && (
            <div style={{ display: 'grid', gap: 18 }}>
              <Legend items={[{ label: 'Achat', color: 'var(--data-buy)', value: '412 800 €' }, { label: 'Location + épargne', color: 'var(--data-rent)', value: '374 400 €' }]} />
              <Chart />
              <p style={{ font: 'var(--type-caption)', fontWeight: 'var(--fw-regular)', color: 'var(--text-muted)' }}>
                Patrimoine net cumulé, en euros courants. Côté achat : valeur du bien moins capital restant dû, plus l'épargne placée.
              </p>
            </div>
          )}

          {vue === 'table' && (
            <DataTable
              columns={[{ key: 'an', label: 'Année' }, { key: 'achat', label: 'Achat', align: 'right', emphasis: true }, { key: 'loc', label: 'Location + épargne', align: 'right' }, { key: 'ecart', label: 'Écart', align: 'right' }]}
              rows={ROWS} />
          )}

          {vue === 'hyp' && (
            <div style={{ display: 'grid', gap: 14 }}>
              {[['Rendement bourse (brut)', '5,5 % / an'], ['Fiscalité de sortie', '31,4 % — compte-titres'], ['Revalorisation du bien', '1,5 % / an'], ['Indexation des loyers', '1,9 % / an'], ['Frais de notaire', '7,8 % — ancien'], ['Taux nominal du crédit', '3,35 % sur 20 ans'], ['Assurance emprunteur', '0,34 % du capital initial']].map((r) => (
                <div key={r[0]} style={{ display: 'flex', justifyContent: 'space-between', paddingBottom: 12, borderBottom: '1px solid var(--border-hairline)' }}>
                  <span style={{ fontSize: 'var(--fs-body-s)', color: 'var(--text-body)' }}>{r[0]}</span>
                  <span style={{ fontSize: 'var(--fs-body-s)', fontWeight: 'var(--fw-semibold)', color: 'var(--text-title)', fontVariantNumeric: 'tabular-nums' }}>{r[1]}</span>
                </div>
              ))}
              <Button variant="secondary" iconLeft="pencil" onClick={() => onNavigate('simulateur')} style={{ justifySelf: 'start', marginTop: 4 }}>Modifier les hypothèses</Button>
            </div>
          )}
        </Card>

        <div style={{ display: 'grid', gap: 16 }}>
          <Card title="Où part l'argent" padding={24}>
            <ComparisonBar
              items={[{ label: 'Achat — intérêts et frais perdus', value: 96400 }, { label: 'Location — loyers versés', value: 178200 }]}
              formatValue={(v) => v.toLocaleString('fr-FR') + ' €'} />
          </Card>
          <Card tone="accent" padding={24} elevation={1}>
            <div style={{ display: 'grid', gap: 10 }}>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8, font: 'var(--type-eyebrow)', textTransform: 'uppercase', letterSpacing: 'var(--ls-caps)', color: 'var(--clay-700)' }}>
                <Icon name="lightbulb" size={15} /> CE QUI CHANGE TOUT
              </span>
              <p style={{ fontSize: 'var(--fs-body-s)', color: 'var(--text-body)' }}>
                Avec un rendement boursier de 7 % au lieu de 5,5 %, la location repasse devant : <DeltaValue value="−14 200" unit="€" size="s" /> pour l'achat.
              </p>
              <Button variant="ghost" size="s" iconRight="arrow-right" onClick={() => onNavigate('simulateur')} style={{ justifySelf: 'start', paddingLeft: 0 }}>Tester ce scénario</Button>
            </div>
          </Card>
          <Callout tone="warning" title="Revente avant 7 ans">
            Les frais de notaire et les intérêts des premières années ne sont pas amortis : sur un horizon court, rester locataire reste plus favorable.
          </Callout>
        </div>
      </section>

      {save && (
        <Dialog title="Enregistrer cette simulation" description="Vous la retrouverez dans votre espace, avec toutes ses hypothèses."
          onClose={() => setSave(false)}
          footer={<><Button variant="quiet" onClick={() => setSave(false)}>Annuler</Button><Button onClick={() => setSave(false)}>Enregistrer</Button></>}>
          <Field label="Nom de la simulation"><TextInput defaultValue="Lyon 3e — 320 000 € — 12 ans" /></Field>
        </Dialog>
      )}
    </main>
  );
}

Object.assign(window, { Resultats });
