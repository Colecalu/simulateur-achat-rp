const { Button, Card, Badge, Callout, Icon, StatTile, ComparisonBar, Legend } = window.PerronDesignSystem_49e698;

const STEPS = [
  { icon: 'house', t: 'Décrivez le bien', d: "Prix, ville, ancien ou neuf, apport et durée de détention envisagée." },
  { icon: 'wallet', t: 'Fixez votre enveloppe', d: "Un même budget mensuel des deux côtés : mensualité et charges, ou loyer et épargne." },
  { icon: 'scale', t: "Comparez net d'impôt", d: 'Patrimoine net année par année, des deux côtés, une fois la fiscalité déduite.' },
];

function Landing({ onNavigate }) {
  return (
    <main>
      <section style={{ position: 'relative', overflow: 'hidden' }}>
        <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', padding: '72px var(--gutter-desktop) 88px', display: 'grid', gridTemplateColumns: '1.05fr .95fr', gap: 56, alignItems: 'center' }}>
          <div style={{ display: 'grid', gap: 22, justifyItems: 'start' }}>
            <Badge tone="accent" icon="scale">Comparaison à budget identique</Badge>
            <h1 style={{ fontSize: 'var(--fs-display-xl)', maxWidth: 620 }}>
              Acheter ou louer<span style={{ color: 'var(--clay-500)' }}>&#8239;?</span> <i style={{ color: 'var(--text-muted)' }}>Chiffres à l'appui.</i>
            </h1>
            <p style={{ fontSize: 'var(--fs-body-l)', color: 'var(--text-body)', maxWidth: 520 }}>
              Le simulateur répartit la même enveloppe mensuelle sur deux trajectoires — devenir propriétaire, ou rester locataire et investir la différence — puis compare votre patrimoine net à la date que vous choisissez.
            </p>
            <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
              <Button size="l" iconRight="arrow-right" onClick={() => onNavigate('simulateur')}>Faire ma simulation</Button>
              <Button size="l" variant="secondary" iconLeft="file-text" onClick={() => onNavigate('resultats')}>Voir un exemple</Button>
            </div>
            <span style={{ font: 'var(--type-caption)', fontWeight: 'var(--fw-regular)', color: 'var(--text-muted)' }}>Gratuit, sans compte — 4 minutes de saisie.</span>
          </div>

          <Card padding={0} elevation={3} style={{ overflow: 'hidden' }}>
            <div style={{ position: 'relative', padding: '22px 26px', background: 'var(--clay-500)', color: 'var(--paper-50)', overflow: 'hidden' }}>
              <span style={{ position: 'absolute', inset: 0, backgroundImage: 'url(../../assets/grain.png)', opacity: 0.3 }} />
              <div style={{ position: 'relative', display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                <span style={{ font: 'var(--type-eyebrow)', textTransform: 'uppercase', letterSpacing: 'var(--ls-caps)', color: 'var(--clay-100)' }}>EXEMPLE — LYON 3E, 320 000 €</span>
                <span style={{ font: 'var(--type-caption)' }}>12 ans</span>
              </div>
              <div style={{ position: 'relative', fontFamily: 'var(--font-display)', fontSize: 'var(--fs-display-s)', marginTop: 8 }}>
                Acheter laisse 38 400 € de plus
              </div>
            </div>
            <div style={{ padding: 26, display: 'grid', gap: 22 }}>
              <ComparisonBar items={[{ label: 'Patrimoine net — achat', value: 412800 }, { label: 'Patrimoine net — location + épargne', value: 374400 }]} formatValue={(v) => v.toLocaleString('fr-FR') + ' €'} />
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                <StatTile size="s" label="Enveloppe mensuelle" value="1 850" unit="€" icon="wallet" />
                <StatTile size="s" label="Point de bascule" value="7,2" unit="ans" icon="clock" tone="buy" />
              </div>
            </div>
          </Card>
        </div>
      </section>

      <section style={{ background: 'var(--surface-sunken)', borderTop: '1px solid var(--border-hairline)', borderBottom: '1px solid var(--border-hairline)' }}>
        <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', padding: 'var(--section-y-desktop) var(--gutter-desktop)', display: 'grid', gap: 40 }}>
          <div style={{ display: 'grid', gap: 12, maxWidth: 'var(--container-prose)' }}>
            <h2 style={{ fontSize: 'var(--fs-display-m)' }}>Trois étapes, une seule hypothèse forte</h2>
            <p style={{ fontSize: 'var(--fs-body-l)', color: 'var(--text-body)' }}>
              Les deux trajectoires consomment exactement le même budget. Ce qui n'est pas dépensé en logement est investi en bourse, au même rendement, des deux côtés.
            </p>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20 }}>
            {STEPS.map((s, i) => (
              <Card key={s.t} elevation={1} padding={26}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
                  <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: 44, height: 44, borderRadius: 'var(--radius-m)', background: 'var(--clay-50)', border: '1px solid var(--clay-100)' }}>
                    <Icon name={s.icon} size={22} color="var(--clay-600)" />
                  </span>
                  <span style={{ font: 'var(--type-eyebrow)', textTransform: 'uppercase', letterSpacing: 'var(--ls-caps)', color: 'var(--text-muted)' }}>ÉTAPE {i + 1}</span>
                </div>
                <h3 style={{ fontSize: 'var(--fs-title-s)', marginBottom: 8 }}>{s.t}</h3>
                <p style={{ fontSize: 'var(--fs-body-s)', color: 'var(--text-body)' }}>{s.d}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section>
        <div style={{ maxWidth: 'var(--container-max)', margin: '0 auto', padding: 'var(--section-y-desktop) var(--gutter-desktop)', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 56, alignItems: 'start' }}>
          <div style={{ display: 'grid', gap: 18 }}>
            <h2 style={{ fontSize: 'var(--fs-display-m)' }}>Ce que le calcul prend en compte</h2>
            <p style={{ fontSize: 'var(--fs-body-m)', color: 'var(--text-body)' }}>
              Frais de notaire différenciés ancien et neuf, assurance emprunteur, taxe foncière, charges de copropriété, entretien, et le capital restant dû déduit de la valeur du bien. Côté location, le loyer, son indexation, et l'épargne placée mois après mois.
            </p>
            <Callout tone="info" title="Tout est net d'impôt, des deux côtés">
              Le rendement de la bourse se saisit en brut. La fiscalité de sortie est appliquée au dénouement, avec un taux que vous pouvez modifier — 31,4 % par défaut, le taux d'un compte-titres.
            </Callout>
            <Callout tone="warning" title="Une projection, pas une promesse">
              Personne ne connaît le rendement des marchés ni l'évolution des prix immobiliers sur douze ans. Faites varier les hypothèses : c'est l'écart entre les scénarios qui est instructif, pas le chiffre unique.
            </Callout>
          </div>
          <Card padding={28} elevation={2}>
            <div style={{ display: 'grid', gap: 18 }}>
              <Legend items={[{ label: 'Achat', color: 'var(--data-buy)' }, { label: 'Location + épargne', color: 'var(--data-rent)' }]} />
              {[['Mensualité de crédit', '1 420 €', '—'], ['Charges et entretien', '310 €', '—'], ['Loyer', '—', '1 180 €'], ['Épargne investie', '120 €', '670 €'], ['Enveloppe totale', '1 850 €', '1 850 €']].map((r, i) => (
                <div key={r[0]} style={{ display: 'grid', gridTemplateColumns: '1.4fr .8fr .8fr', gap: 12, paddingBottom: 12, borderBottom: i === 4 ? 'none' : '1px solid var(--border-hairline)', fontWeight: i === 4 ? 'var(--fw-semibold)' : 'var(--fw-regular)' }}>
                  <span style={{ fontSize: 'var(--fs-body-s)', color: i === 4 ? 'var(--text-title)' : 'var(--text-body)' }}>{r[0]}</span>
                  <span style={{ fontSize: 'var(--fs-body-s)', textAlign: 'right', color: 'var(--clay-600)', fontVariantNumeric: 'tabular-nums' }}>{r[1]}</span>
                  <span style={{ fontSize: 'var(--fs-body-s)', textAlign: 'right', color: 'var(--olive-600)', fontVariantNumeric: 'tabular-nums' }}>{r[2]}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </section>

      <section style={{ background: 'var(--clay-500)', position: 'relative', overflow: 'hidden' }}>
        <span style={{ position: 'absolute', inset: 0, backgroundImage: 'url(../../assets/grain.png)', opacity: 0.28 }} />
        <div style={{ position: 'relative', maxWidth: 'var(--container-prose)', margin: '0 auto', padding: '80px var(--gutter-desktop)', textAlign: 'center', display: 'grid', gap: 20, justifyItems: 'center' }}>
          <h2 style={{ color: 'var(--paper-50)', fontSize: 'var(--fs-display-m)' }}>Votre situation n'est pas une moyenne nationale</h2>
          <p style={{ fontSize: 'var(--fs-body-l)', color: 'var(--clay-100)' }}>Quatre minutes de saisie, et vous saurez à partir de quelle année l'achat devient gagnant dans votre cas.</p>
          <Button size="l" variant="secondary" iconRight="arrow-right" onClick={() => onNavigate('simulateur')}>Faire ma simulation</Button>
        </div>
      </section>
    </main>
  );
}

Object.assign(window, { Landing });
