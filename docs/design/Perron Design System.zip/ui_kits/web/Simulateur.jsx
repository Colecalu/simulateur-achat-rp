const { Card, Button, Badge, Field, TextInput, NumberField, Select, SegmentedControl, Slider, Checkbox, Switch, Stepper, Callout, StatTile, Icon, Tooltip } = window.PerronDesignSystem_49e698;

const STEP_LABELS = ['Votre projet', 'Financement', 'Hypothèses', 'Résultat'];

function Simulateur({ onNavigate }) {
  const [step, setStep] = React.useState(1);
  const [type, setType] = React.useState('ancien');
  const [duree, setDuree] = React.useState(12);
  const [rendement, setRendement] = React.useState(5.5);
  const [assurance, setAssurance] = React.useState(true);
  const [indexation, setIndexation] = React.useState(true);

  return (
    <main style={{ maxWidth: 'var(--container-max)', margin: '0 auto', padding: '40px var(--gutter-desktop) 88px' }}>
      <div style={{ display: 'grid', gap: 10, marginBottom: 32 }}>
        <h1 style={{ fontSize: 'var(--fs-display-m)' }}>Votre simulation</h1>
        <p style={{ fontSize: 'var(--fs-body-m)', color: 'var(--text-body)', maxWidth: 'var(--container-prose)' }}>
          Les valeurs par défaut correspondent au marché français en 2026. Modifiez celles que vous connaissez, laissez les autres.
        </p>
      </div>

      <Card padding={20} elevation={1} style={{ marginBottom: 28 }}>
        <Stepper steps={STEP_LABELS} current={step} onStepClick={setStep} />
      </Card>

      <div style={{ display: 'grid', gridTemplateColumns: '1.55fr 1fr', gap: 28, alignItems: 'start' }}>
        <div style={{ display: 'grid', gap: 20 }}>
          <Card title="Le bien" padding={26}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18 }}>
              <Field label="Prix du bien" hint="Hors frais de notaire"><NumberField defaultValue="320 000" unit="€" /></Field>
              <Field label="Ville"><TextInput defaultValue="Lyon 3e" icon="map-pin" /></Field>
              <Field label="Type de bien" hint="Les frais de notaire diffèrent">
                <SegmentedControl value={type} onChange={setType} options={[{ value: 'ancien', label: 'Ancien — 7,8 %' }, { value: 'neuf', label: 'Neuf — 2,9 %' }]} />
              </Field>
              <Field label="Taxe foncière annuelle"><NumberField defaultValue="1 240" unit="€" /></Field>
              <Field label="Charges de copropriété"><NumberField defaultValue="145" unit="€/mois" /></Field>
              <Field label="Entretien annuel" hint="0,8 % de la valeur par défaut"><NumberField defaultValue="2 560" unit="€" /></Field>
            </div>
          </Card>

          <Card title="Le financement" padding={26}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18 }}>
              <Field label="Apport" hint="Frais de notaire inclus"><NumberField defaultValue="60 000" unit="€" /></Field>
              <Field label="Durée du crédit"><Select defaultValue="20" options={[{ value: '15', label: '15 ans' }, { value: '20', label: '20 ans' }, { value: '25', label: '25 ans' }]} /></Field>
              <Field label="Taux nominal"><NumberField defaultValue="3,35" unit="%" /></Field>
              <Field label="Assurance emprunteur"><NumberField defaultValue="0,34" unit="%" disabled={!assurance} /></Field>
              <div style={{ gridColumn: '1 / -1', display: 'grid', gap: 12 }}>
                <Checkbox checked={assurance} onChange={() => setAssurance(!assurance)} label="Inclure l'assurance emprunteur" description="Calculée sur le capital initial, comme la plupart des offres bancaires." />
                <Checkbox checked={indexation} onChange={() => setIndexation(!indexation)} label="Indexer le loyer sur l'inflation" description="IRL estimé à 1,9 % par an." />
              </div>
            </div>
          </Card>

          <Card title="Les hypothèses de marché" padding={26}
            action={<Badge tone="warning" icon="circle-alert">À faire varier</Badge>}>
            <div style={{ display: 'grid', gap: 22 }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 22 }}>
                <Slider label="Durée de détention" value={duree} min={1} max={30} unit="ans" onChange={(e) => setDuree(+e.target.value)} />
                <Slider label="Rendement bourse (brut)" value={rendement} min={0} max={12} step={0.1} unit="%" onChange={(e) => setRendement(+e.target.value)} />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18 }}>
                <Field label="Revalorisation du bien" hint="Par an, en euros courants"><NumberField defaultValue="1,5" unit="%" /></Field>
                <Field
                  label={<span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>Fiscalité de sortie <Tooltip content="Taux appliqué aux plus-values boursières au dénouement. 31,4 % = flat tax d'un compte-titres."><Icon name="info" size={14} color="var(--text-muted)" /></Tooltip></span>}>
                  <Select defaultValue="cto" options={[{ value: 'cto', label: 'Compte-titres — 31,4 %' }, { value: 'pea', label: 'PEA — 17,2 %' }, { value: 'av', label: 'Assurance-vie — 24,7 %' }, { value: 'custom', label: 'Taux personnalisé' }]} />
                </Field>
              </div>
              <Callout tone="tip" title="Le rendement se saisit en brut">
                L'impôt est retiré une seule fois, à la sortie, pour que les deux trajectoires soient comparées nettes.
              </Callout>
            </div>
          </Card>
        </div>

        <div style={{ position: 'sticky', top: 96, display: 'grid', gap: 16 }}>
          <Card tone="sunken" padding={22} elevation={0} title="Enveloppe mensuelle">
            <div style={{ display: 'grid', gap: 14 }}>
              <NumberField defaultValue="1 850" unit="€/mois" size="l" />
              <p style={{ font: 'var(--type-caption)', fontWeight: 'var(--fw-regular)', color: 'var(--text-muted)' }}>
                Le même montant des deux côtés. Côté achat : mensualité, assurance, charges, entretien, taxe foncière. Côté location : loyer, puis épargne du reste.
              </p>
              <div style={{ display: 'grid', gap: 10, paddingTop: 4 }}>
                {[['Achat — logement', '1 730 €', 'var(--data-buy)'], ['Achat — épargne', '120 €', 'var(--data-buy)'], ['Location — loyer', '1 180 €', 'var(--data-rent)'], ['Location — épargne', '670 €', 'var(--data-rent)']].map((r) => (
                  <div key={r[0]} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12 }}>
                    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8, fontSize: 'var(--fs-body-s)', color: 'var(--text-body)' }}>
                      <span style={{ width: 8, height: 8, borderRadius: '50%', background: r[2] }} />{r[0]}
                    </span>
                    <span style={{ fontSize: 'var(--fs-body-s)', fontWeight: 'var(--fw-semibold)', color: 'var(--text-title)', fontVariantNumeric: 'tabular-nums' }}>{r[1]}</span>
                  </div>
                ))}
              </div>
            </div>
          </Card>

          <StatTile label={'Aperçu à ' + duree + ' ans'} value={'+' + Math.round(3200 * duree).toLocaleString('fr-FR')} unit="€" tone="positive" icon="scale" note="En faveur de l'achat, net d'impôt" />

          <Button size="l" fullWidth iconRight="arrow-right" onClick={() => onNavigate('resultats')}>Voir le résultat détaillé</Button>
          <Button size="m" variant="quiet" fullWidth iconLeft="refresh-ccw">Repartir des valeurs par défaut</Button>
        </div>
      </div>
    </main>
  );
}

Object.assign(window, { Simulateur });
