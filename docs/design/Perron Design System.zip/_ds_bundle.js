/* @ds-bundle: {"format":4,"namespace":"PerronDesignSystem_49e698","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Callout","sourcePath":"components/core/Callout.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"ComparisonBar","sourcePath":"components/data/ComparisonBar.jsx"},{"name":"DataTable","sourcePath":"components/data/DataTable.jsx"},{"name":"DeltaValue","sourcePath":"components/data/DeltaValue.jsx"},{"name":"Legend","sourcePath":"components/data/Legend.jsx"},{"name":"StatTile","sourcePath":"components/data/StatTile.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Field","sourcePath":"components/forms/Field.jsx"},{"name":"NumberField","sourcePath":"components/forms/NumberField.jsx"},{"name":"SegmentedControl","sourcePath":"components/forms/SegmentedControl.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Slider","sourcePath":"components/forms/Slider.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"TextInput","sourcePath":"components/forms/TextInput.jsx"},{"name":"Stepper","sourcePath":"components/navigation/Stepper.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"fbc64b569ae7","components/core/Button.jsx":"ea98cb4de2e9","components/core/Callout.jsx":"d4f836d4d963","components/core/Card.jsx":"ec14acf4f406","components/core/Icon.jsx":"b8d244d482d7","components/core/IconButton.jsx":"f5024c0bec0e","components/data/ComparisonBar.jsx":"43c1a39e694f","components/data/DataTable.jsx":"e6211fd50ec7","components/data/DeltaValue.jsx":"3c766de8e759","components/data/Legend.jsx":"2b3b9da695a2","components/data/StatTile.jsx":"e60a0d3b34ed","components/feedback/Dialog.jsx":"5c6c26cdb61f","components/feedback/Tooltip.jsx":"808f495b1897","components/forms/Checkbox.jsx":"95ce95cc6092","components/forms/Field.jsx":"5289c8a4eb41","components/forms/NumberField.jsx":"3e1cfc0cba92","components/forms/SegmentedControl.jsx":"de985229591f","components/forms/Select.jsx":"05f8d9c7ab0b","components/forms/Slider.jsx":"cacfbe4d5264","components/forms/Switch.jsx":"e1add58de8e8","components/forms/TextInput.jsx":"e58bba31a974","components/navigation/Stepper.jsx":"d2366c6a7c6f","components/navigation/Tabs.jsx":"8d7e76268996","ui_kits/web/Chrome.jsx":"a870c04b2e84","ui_kits/web/Landing.jsx":"10350ec74fe2","ui_kits/web/Resultats.jsx":"6058ca470dea","ui_kits/web/Simulateur.jsx":"55183cd5dfeb"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.PerronDesignSystem_49e698 = window.PerronDesignSystem_49e698 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  paper: {
    background: 'var(--surface-card)',
    border: '1px solid var(--border-default)'
  },
  sunken: {
    background: 'var(--surface-sunken)',
    border: '1px solid var(--border-hairline)'
  },
  accent: {
    background: 'var(--clay-50)',
    border: '1px solid var(--clay-100)'
  },
  secondary: {
    background: 'var(--olive-50)',
    border: '1px solid var(--olive-100)'
  },
  inverse: {
    background: 'var(--surface-inverse)',
    border: '1px solid var(--surface-inverse)',
    color: 'var(--text-inverse)'
  }
};

/** Conteneur de contenu : papier, filet chaud, coins 20 px. */
function Card({
  tone = 'paper',
  elevation = 2,
  padding = 24,
  title,
  action,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      borderRadius: 'var(--radius-card)',
      boxShadow: elevation === 0 ? 'none' : 'var(--shadow-' + elevation + ')',
      padding,
      ...TONES[tone],
      ...style
    }
  }), (title || action) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 16,
      marginBottom: 16
    }
  }, title ? /*#__PURE__*/React.createElement("h3", {
    style: {
      font: 'var(--type-title)',
      fontSize: 'var(--fs-title-s)',
      color: tone === 'inverse' ? 'var(--text-inverse)' : 'var(--text-title)'
    }
  }, title) : /*#__PURE__*/React.createElement("span", null), action), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
let cachedBase = null;
function resolveBase() {
  if (cachedBase) return cachedBase;
  if (typeof document !== 'undefined') {
    const s = Array.from(document.querySelectorAll('script[src]')).find(function (n) {
      return n.getAttribute('src').indexOf('_ds_bundle.js') !== -1;
    });
    if (s) {
      const src = s.getAttribute('src');
      cachedBase = src.slice(0, src.lastIndexOf('/') + 1) + 'assets/icons/';
      return cachedBase;
    }
  }
  cachedBase = 'assets/icons/';
  return cachedBase;
}

/** Glyphe Lucide colore via currentColor (masque CSS). */
function Icon({
  name,
  size = 20,
  strokeWidth,
  color = 'currentColor',
  style,
  ...rest
}) {
  const url = resolveBase() + name + '.svg';
  return /*#__PURE__*/React.createElement("span", _extends({
    "aria-hidden": "true"
  }, rest, {
    style: {
      display: 'inline-block',
      flex: '0 0 auto',
      width: size,
      height: size,
      backgroundColor: color,
      WebkitMaskImage: 'url(' + url + ')',
      maskImage: 'url(' + url + ')',
      WebkitMaskRepeat: 'no-repeat',
      maskRepeat: 'no-repeat',
      WebkitMaskPosition: 'center',
      maskPosition: 'center',
      WebkitMaskSize: 'contain',
      maskSize: 'contain',
      opacity: strokeWidth === 'light' ? 0.7 : 1,
      ...style
    }
  }));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  neutral: {
    background: 'var(--paper-200)',
    color: 'var(--text-body)'
  },
  accent: {
    background: 'var(--clay-100)',
    color: 'var(--clay-700)'
  },
  secondary: {
    background: 'var(--olive-100)',
    color: 'var(--olive-700)'
  },
  positive: {
    background: 'var(--green-100)',
    color: 'var(--green-700)'
  },
  warning: {
    background: 'var(--ochre-100)',
    color: 'var(--ochre-700)'
  },
  negative: {
    background: 'var(--brick-100)',
    color: 'var(--brick-700)'
  }
};

/** Pastille d'etat ou de categorie. */
function Badge({
  tone = 'neutral',
  icon,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      padding: '5px 11px',
      borderRadius: 'var(--radius-pill)',
      font: 'var(--type-caption)',
      letterSpacing: '0.01em',
      ...TONES[tone],
      ...style
    }
  }), icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 14
  }) : null, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  s: {
    height: 'var(--control-h-s)',
    padding: '0 16px',
    fontSize: 'var(--fs-body-s)',
    gap: 7,
    icon: 16
  },
  m: {
    height: 'var(--control-h-m)',
    padding: '0 22px',
    fontSize: 'var(--fs-body-m)',
    gap: 9,
    icon: 18
  },
  l: {
    height: 'var(--control-h-l)',
    padding: '0 30px',
    fontSize: 'var(--fs-body-l)',
    gap: 10,
    icon: 20
  }
};
const VARIANTS = {
  primary: {
    background: 'var(--clay-500)',
    color: 'var(--text-inverse)',
    border: '1px solid var(--clay-500)',
    boxShadow: 'var(--shadow-2)',
    hover: {
      background: 'var(--clay-600)',
      borderColor: 'var(--clay-600)'
    }
  },
  secondary: {
    background: 'var(--surface-card)',
    color: 'var(--text-title)',
    border: '1px solid var(--border-default)',
    boxShadow: 'var(--shadow-1)',
    hover: {
      background: 'var(--paper-200)',
      borderColor: 'var(--border-strong)'
    }
  },
  ghost: {
    background: 'transparent',
    color: 'var(--text-accent)',
    border: '1px solid transparent',
    boxShadow: 'none',
    hover: {
      background: 'var(--clay-50)'
    }
  },
  quiet: {
    background: 'var(--paper-200)',
    color: 'var(--text-body)',
    border: '1px solid transparent',
    boxShadow: 'none',
    hover: {
      background: 'var(--paper-300)'
    }
  }
};

/** Bouton d'action. */
function Button({
  variant = 'primary',
  size = 'm',
  iconLeft,
  iconRight,
  fullWidth,
  disabled,
  children,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const s = SIZES[size] || SIZES.m;
  const v = VARIANTS[variant] || VARIANTS.primary;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: disabled,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPress(false);
    },
    onMouseDown: () => setPress(true),
    onMouseUp: () => setPress(false)
  }, rest, {
    style: {
      display: fullWidth ? 'flex' : 'inline-flex',
      width: fullWidth ? '100%' : undefined,
      alignItems: 'center',
      justifyContent: 'center',
      gap: s.gap,
      height: s.height,
      padding: s.padding,
      font: 'var(--type-body)',
      fontSize: s.fontSize,
      fontWeight: 'var(--fw-medium)',
      borderRadius: 'var(--radius-control)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      transition: 'var(--transition-control)',
      whiteSpace: 'nowrap',
      ...v,
      ...(hover && !disabled ? v.hover : null),
      transform: press && !disabled ? 'translateY(1px)' : 'none',
      opacity: disabled ? 0.42 : 1,
      ...style
    }
  }), iconLeft ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconLeft,
    size: s.icon
  }) : null, children, iconRight ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconRight,
    size: s.icon
  }) : null);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Callout.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  info: {
    background: 'var(--clay-50)',
    border: 'var(--clay-100)',
    icon: 'info',
    color: 'var(--clay-700)'
  },
  tip: {
    background: 'var(--olive-50)',
    border: 'var(--olive-100)',
    icon: 'lightbulb',
    color: 'var(--olive-700)'
  },
  warning: {
    background: 'var(--ochre-100)',
    border: '#EBD8AE',
    icon: 'circle-alert',
    color: 'var(--ochre-700)'
  },
  danger: {
    background: 'var(--brick-100)',
    border: '#EFC7BD',
    icon: 'circle-alert',
    color: 'var(--brick-700)'
  }
};

/** Encart explicatif inline. */
function Callout({
  tone = 'info',
  icon,
  title,
  children,
  style,
  ...rest
}) {
  const t = TONES[tone] || TONES.info;
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: 'flex',
      gap: 12,
      padding: '16px 18px',
      background: t.background,
      border: '1px solid ' + t.border,
      borderRadius: 'var(--radius-m)',
      ...style
    }
  }), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon || t.icon,
    size: 20,
    color: t.color,
    style: {
      marginTop: 1
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 4
    }
  }, title ? /*#__PURE__*/React.createElement("strong", {
    style: {
      font: 'var(--type-body)',
      fontWeight: 'var(--fw-semibold)',
      color: t.color
    }
  }, title) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--type-body)',
      fontSize: 'var(--fs-body-s)',
      color: 'var(--text-body)'
    }
  }, children)));
}
Object.assign(__ds_scope, { Callout });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Callout.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  s: 32,
  m: 40,
  l: 48
};

/** Bouton carre ne portant qu'une icone. */
function IconButton({
  icon,
  label,
  variant = 'secondary',
  size = 'm',
  disabled,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const d = SIZES[size] || SIZES.m;
  const skin = variant === 'primary' ? {
    background: 'var(--clay-500)',
    color: 'var(--text-inverse)',
    border: '1px solid var(--clay-500)'
  } : variant === 'ghost' ? {
    background: hover ? 'var(--paper-200)' : 'transparent',
    color: 'var(--text-body)',
    border: '1px solid transparent'
  } : {
    background: hover ? 'var(--paper-200)' : 'var(--surface-card)',
    color: 'var(--text-title)',
    border: '1px solid var(--border-default)'
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": label,
    title: label,
    disabled: disabled,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false)
  }, rest, {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: d,
      height: d,
      borderRadius: 'var(--radius-control)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.42 : 1,
      transition: 'var(--transition-control)',
      ...skin,
      ...(variant === 'primary' && hover ? {
        background: 'var(--clay-600)',
        borderColor: 'var(--clay-600)'
      } : null),
      ...style
    }
  }), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: size === 's' ? 16 : size === 'l' ? 22 : 19
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/data/ComparisonBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Deux barres horizontales comparant achat et location. */
function ComparisonBar({
  items = [],
  max,
  formatValue,
  style,
  ...rest
}) {
  const top = max || Math.max.apply(null, items.map(function (i) {
    return i.value;
  }).concat([1]));
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: 'grid',
      gap: 16,
      ...style
    }
  }), items.map(function (item, i) {
    const color = item.color || (i === 0 ? 'var(--data-buy)' : 'var(--data-rent)');
    const pct = Math.max(2, item.value / top * 100);
    return /*#__PURE__*/React.createElement("div", {
      key: item.label,
      style: {
        display: 'grid',
        gap: 7
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'baseline',
        gap: 12
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--type-body)',
        fontSize: 'var(--fs-body-s)',
        color: 'var(--text-body)'
      }
    }, item.label), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontWeight: 'var(--fw-semibold)',
        fontSize: 'var(--fs-body-l)',
        color: 'var(--text-title)',
        fontVariantNumeric: 'tabular-nums lining-nums'
      }
    }, formatValue ? formatValue(item.value) : item.value)), /*#__PURE__*/React.createElement("div", {
      style: {
        height: 14,
        borderRadius: 'var(--radius-pill)',
        background: 'var(--paper-300)',
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: pct + '%',
        height: '100%',
        background: color,
        borderRadius: 'var(--radius-pill)',
        transition: 'width var(--dur-slow) var(--ease-out-soft)'
      }
    })));
  }));
}
Object.assign(__ds_scope, { ComparisonBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/ComparisonBar.jsx", error: String((e && e.message) || e) }); }

// components/data/DataTable.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Tableau de valeurs, chiffres en tabulaires alignes a droite. */
function DataTable({
  columns = [],
  rows = [],
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      overflowX: 'auto',
      ...style
    }
  }), /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse',
      font: 'var(--type-body)',
      fontSize: 'var(--fs-body-s)'
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, columns.map(function (c) {
    return /*#__PURE__*/React.createElement("th", {
      key: c.key,
      style: {
        textAlign: c.align || 'left',
        padding: '10px 14px',
        font: 'var(--type-eyebrow)',
        textTransform: 'uppercase',
        letterSpacing: 'var(--ls-caps)',
        color: 'var(--text-muted)',
        borderBottom: '1px solid var(--border-default)',
        whiteSpace: 'nowrap'
      }
    }, c.label);
  }))), /*#__PURE__*/React.createElement("tbody", null, rows.map(function (r, i) {
    return /*#__PURE__*/React.createElement("tr", {
      key: i,
      style: {
        background: i % 2 ? 'var(--paper-100)' : 'transparent'
      }
    }, columns.map(function (c) {
      return /*#__PURE__*/React.createElement("td", {
        key: c.key,
        style: {
          textAlign: c.align || 'left',
          padding: '12px 14px',
          color: c.emphasis ? 'var(--text-title)' : 'var(--text-body)',
          fontWeight: c.emphasis ? 'var(--fw-semibold)' : 'var(--fw-regular)',
          fontVariantNumeric: c.align === 'right' ? 'tabular-nums lining-nums' : 'normal',
          borderBottom: '1px solid var(--border-hairline)',
          whiteSpace: 'nowrap'
        }
      }, r[c.key]);
    }));
  }))));
}
Object.assign(__ds_scope, { DataTable });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/DataTable.jsx", error: String((e && e.message) || e) }); }

// components/data/DeltaValue.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Ecart chiffre, signe et colore. */
function DeltaValue({
  value,
  unit,
  direction,
  size = 'm',
  showIcon = true,
  style,
  ...rest
}) {
  const dir = direction || (String(value).trim().charAt(0) === '-' ? 'down' : 'up');
  const color = dir === 'down' ? 'var(--data-negative)' : 'var(--data-positive)';
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      color,
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--fw-semibold)',
      fontSize: size === 'l' ? 'var(--fs-num-m)' : size === 's' ? 'var(--fs-body-s)' : 'var(--fs-body-l)',
      fontVariantNumeric: 'tabular-nums lining-nums',
      ...style
    }
  }), showIcon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: dir === 'down' ? 'trending-down' : 'trending-up',
    size: size === 's' ? 14 : 17
  }) : null, value, unit ? '\u00A0' + unit : '');
}
Object.assign(__ds_scope, { DeltaValue });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/DeltaValue.jsx", error: String((e && e.message) || e) }); }

// components/data/Legend.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Legende de graphique, pastilles rondes. */
function Legend({
  items = [],
  direction = 'row',
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: 'flex',
      flexDirection: direction === 'column' ? 'column' : 'row',
      flexWrap: 'wrap',
      gap: direction === 'column' ? 8 : 18,
      ...style
    }
  }), items.map(function (item) {
    return /*#__PURE__*/React.createElement("span", {
      key: item.label,
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 8,
        font: 'var(--type-body)',
        fontSize: 'var(--fs-body-s)',
        color: 'var(--text-body)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 10,
        height: 10,
        borderRadius: '50%',
        background: item.color,
        flex: '0 0 auto'
      }
    }), item.label, item.value ? /*#__PURE__*/React.createElement("strong", {
      style: {
        fontWeight: 'var(--fw-semibold)',
        color: 'var(--text-title)',
        fontVariantNumeric: 'tabular-nums lining-nums'
      }
    }, item.value) : null);
  }));
}
Object.assign(__ds_scope, { Legend });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Legend.jsx", error: String((e && e.message) || e) }); }

// components/data/StatTile.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  neutral: {
    accent: 'var(--warm-300)',
    value: 'var(--text-title)'
  },
  buy: {
    accent: 'var(--data-buy)',
    value: 'var(--clay-600)'
  },
  rent: {
    accent: 'var(--data-rent)',
    value: 'var(--olive-600)'
  },
  positive: {
    accent: 'var(--data-positive)',
    value: 'var(--green-700)'
  },
  negative: {
    accent: 'var(--data-negative)',
    value: 'var(--brick-700)'
  }
};

/** Chiffre cle avec libelle, unite et note. */
function StatTile({
  label,
  value,
  unit,
  note,
  icon,
  tone = 'neutral',
  size = 'm',
  style,
  ...rest
}) {
  const t = TONES[tone] || TONES.neutral;
  const fs = size === 'l' ? 'var(--fs-num-xl)' : size === 's' ? 'var(--fs-num-m)' : 'var(--fs-num-l)';
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: 'grid',
      gap: 6,
      padding: '18px 20px',
      background: 'var(--surface-card)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-m)',
      boxShadow: 'var(--shadow-1)',
      ...style
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 7,
      font: 'var(--type-caption)',
      color: 'var(--text-muted)'
    }
  }, icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 15,
    color: t.accent
  }) : null, label), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 6,
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--fw-semibold)',
      fontSize: fs,
      lineHeight: 1.05,
      letterSpacing: 'var(--ls-display)',
      color: t.value,
      fontVariantNumeric: 'tabular-nums lining-nums'
    }
  }, value, unit ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--fs-body-m)',
      fontWeight: 'var(--fw-medium)',
      color: 'var(--text-muted)'
    }
  }, unit) : null), note ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      fontWeight: 'var(--fw-regular)',
      color: 'var(--text-muted)'
    }
  }, note) : null);
}
Object.assign(__ds_scope, { StatTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/StatTile.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Fenetre modale centree. */
function Dialog({
  open = true,
  title,
  description,
  footer,
  onClose,
  width = 520,
  children,
  style,
  ...rest
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      zIndex: 50,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 24,
      background: 'rgba(42,33,27,.42)',
      backdropFilter: 'blur(3px)'
    },
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", _extends({
    role: "dialog",
    "aria-modal": "true",
    onClick: function (e) {
      e.stopPropagation();
    }
  }, rest, {
    style: {
      width: '100%',
      maxWidth: width,
      background: 'var(--surface-card)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-sheet)',
      boxShadow: 'var(--shadow-3)',
      padding: 28,
      display: 'grid',
      gap: 18,
      ...style
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--fw-regular)',
      fontSize: 'var(--fs-title-l)',
      lineHeight: 'var(--lh-snug)',
      color: 'var(--text-title)'
    }
  }, title), description ? /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body)',
      fontSize: 'var(--fs-body-s)',
      color: 'var(--text-body)'
    }
  }, description) : null), onClose ? /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    label: "Fermer",
    variant: "ghost",
    size: "s",
    onClick: onClose
  }) : null), children, footer ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: 10
    }
  }, footer) : null));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Infobulle sombre au survol ou au focus. */
function Tooltip({
  content,
  placement = 'top',
  children,
  style,
  ...rest
}) {
  const [open, setOpen] = React.useState(false);
  const pos = placement === 'bottom' ? {
    top: 'calc(100% + 8px)',
    left: '50%',
    transform: 'translateX(-50%)'
  } : {
    bottom: 'calc(100% + 8px)',
    left: '50%',
    transform: 'translateX(-50%)'
  };
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    onMouseEnter: () => setOpen(true),
    onMouseLeave: () => setOpen(false),
    onFocus: () => setOpen(true),
    onBlur: () => setOpen(false),
    style: {
      position: 'relative',
      display: 'inline-flex',
      ...style
    }
  }), children, /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    style: {
      position: 'absolute',
      ...pos,
      zIndex: 20,
      maxWidth: 260,
      width: 'max-content',
      padding: '9px 12px',
      borderRadius: 'var(--radius-s)',
      background: 'var(--surface-inverse)',
      color: 'var(--text-inverse)',
      font: 'var(--type-caption)',
      fontWeight: 'var(--fw-regular)',
      lineHeight: 1.45,
      boxShadow: 'var(--shadow-3)',
      pointerEvents: 'none',
      opacity: open ? 1 : 0,
      transition: 'opacity var(--dur-fast) var(--ease-standard)'
    }
  }, content));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Case a cocher avec libelle. */
function Checkbox({
  checked,
  onChange,
  label,
  description,
  disabled,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      gap: 12,
      alignItems: 'flex-start',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    checked: checked,
    onChange: onChange,
    disabled: disabled
  }, rest, {
    style: {
      position: 'absolute',
      opacity: 0,
      width: 1,
      height: 1
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flex: '0 0 auto',
      width: 22,
      height: 22,
      marginTop: 1,
      borderRadius: 'var(--radius-xs)',
      background: checked ? 'var(--clay-500)' : 'var(--surface-card)',
      border: '1px solid ' + (checked ? 'var(--clay-500)' : 'var(--border-strong)'),
      boxShadow: checked ? 'none' : 'var(--shadow-inset-field)',
      transition: 'var(--transition-control)'
    }
  }, checked ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 15,
    color: "var(--text-inverse)"
  }) : null), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'grid',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-body)',
      fontSize: 'var(--fs-body-s)',
      color: 'var(--text-title)'
    }
  }, label), description ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      fontWeight: 'var(--fw-regular)',
      color: 'var(--text-muted)'
    }
  }, description) : null));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Field.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Enveloppe libelle + aide + erreur autour d'un controle de saisie. */
function Field({
  label,
  hint,
  error,
  htmlFor,
  info,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: 'grid',
      gap: 7,
      ...style
    }
  }), label ? /*#__PURE__*/React.createElement("label", {
    htmlFor: htmlFor,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      font: 'var(--type-body)',
      fontSize: 'var(--fs-body-s)',
      fontWeight: 'var(--fw-medium)',
      color: 'var(--text-title)'
    }
  }, label, info ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "info",
    size: 14,
    color: "var(--text-muted)",
    title: info
  }) : null) : null, children, error ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      color: 'var(--brick-500)'
    }
  }, error) : hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      fontWeight: 'var(--fw-regular)',
      color: 'var(--text-muted)'
    }
  }, hint) : null);
}
Object.assign(__ds_scope, { Field });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Field.jsx", error: String((e && e.message) || e) }); }

// components/forms/NumberField.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const H = {
  s: 'var(--control-h-s)',
  m: 'var(--control-h-m)',
  l: 'var(--control-h-l)'
};

/** Saisie numerique avec unite suffixee — le controle de base du simulateur. */
function NumberField({
  value,
  onChange,
  unit = '\u20AC',
  size = 'm',
  align = 'right',
  invalid,
  disabled,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      height: H[size],
      background: disabled ? 'var(--paper-200)' : 'var(--surface-card)',
      border: '1px solid ' + (invalid ? 'var(--brick-500)' : focus ? 'var(--clay-400)' : 'var(--border-default)'),
      borderRadius: 'var(--radius-field)',
      boxShadow: focus ? 'var(--ring-focus)' : 'var(--shadow-inset-field)',
      transition: 'var(--transition-control)',
      overflow: 'hidden',
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    inputMode: "decimal",
    value: value,
    onChange: onChange,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false)
  }, rest, {
    style: {
      flex: 1,
      minWidth: 0,
      height: '100%',
      padding: '0 4px 0 16px',
      border: 'none',
      background: 'transparent',
      font: 'var(--type-body)',
      fontWeight: 'var(--fw-medium)',
      color: 'var(--text-title)',
      fontVariantNumeric: 'tabular-nums lining-nums',
      textAlign: align,
      outline: 'none'
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      padding: '0 16px 0 8px',
      font: 'var(--type-body)',
      fontSize: 'var(--fs-body-s)',
      color: 'var(--text-muted)',
      whiteSpace: 'nowrap'
    }
  }, unit));
}
Object.assign(__ds_scope, { NumberField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/NumberField.jsx", error: String((e && e.message) || e) }); }

// components/forms/SegmentedControl.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Choix exclusif entre 2 a 4 options courtes. */
function SegmentedControl({
  options = [],
  value,
  onChange,
  size = 'm',
  fullWidth = true,
  style,
  ...rest
}) {
  const h = size === 's' ? 34 : size === 'l' ? 50 : 42;
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "tablist"
  }, rest, {
    style: {
      display: fullWidth ? 'grid' : 'inline-grid',
      gridTemplateColumns: 'repeat(' + options.length + ', 1fr)',
      gap: 3,
      padding: 3,
      background: 'var(--paper-200)',
      border: '1px solid var(--border-hairline)',
      borderRadius: 'var(--radius-control)',
      ...style
    }
  }), options.map(function (o) {
    const opt = typeof o === 'string' ? {
      value: o,
      label: o
    } : o;
    const active = opt.value === value;
    return /*#__PURE__*/React.createElement("button", {
      key: opt.value,
      type: "button",
      role: "tab",
      "aria-selected": active,
      onClick: function () {
        if (onChange) onChange(opt.value);
      },
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 7,
        height: h,
        padding: '0 14px',
        border: 'none',
        cursor: 'pointer',
        borderRadius: 'calc(var(--radius-control) - 3px)',
        background: active ? 'var(--surface-card)' : 'transparent',
        boxShadow: active ? 'var(--shadow-1)' : 'none',
        color: active ? 'var(--text-title)' : 'var(--text-muted)',
        font: 'var(--type-body)',
        fontSize: size === 's' ? 'var(--fs-body-s)' : 'var(--fs-body-m)',
        fontWeight: active ? 'var(--fw-semibold)' : 'var(--fw-medium)',
        transition: 'var(--transition-control)',
        whiteSpace: 'nowrap'
      }
    }, opt.icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: opt.icon,
      size: 16
    }) : null, opt.label);
  }));
}
Object.assign(__ds_scope, { SegmentedControl });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/SegmentedControl.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const H = {
  s: 'var(--control-h-s)',
  m: 'var(--control-h-m)',
  l: 'var(--control-h-l)'
};

/** Liste deroulante native habillee. */
function Select({
  options = [],
  value,
  onChange,
  size = 'm',
  disabled,
  invalid,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    value: value,
    onChange: onChange,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false)
  }, rest, {
    style: {
      WebkitAppearance: 'none',
      appearance: 'none',
      width: '100%',
      height: H[size],
      padding: '0 42px 0 16px',
      font: 'var(--type-body)',
      color: 'var(--text-title)',
      background: disabled ? 'var(--paper-200)' : 'var(--surface-card)',
      border: '1px solid ' + (invalid ? 'var(--brick-500)' : focus ? 'var(--clay-400)' : 'var(--border-default)'),
      borderRadius: 'var(--radius-field)',
      boxShadow: focus ? 'var(--ring-focus)' : 'var(--shadow-inset-field)',
      outline: 'none',
      cursor: disabled ? 'not-allowed' : 'pointer',
      transition: 'var(--transition-control)',
      ...style
    }
  }), options.map(function (o) {
    const opt = typeof o === 'string' ? {
      value: o,
      label: o
    } : o;
    return /*#__PURE__*/React.createElement("option", {
      key: opt.value,
      value: opt.value
    }, opt.label);
  })), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-down",
    size: 18,
    color: "var(--text-muted)",
    style: {
      position: 'absolute',
      right: 14,
      pointerEvents: 'none'
    }
  }));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Slider.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Curseur de reglage, avec valeur lisible au-dessus de la piste. */
function Slider({
  value = 0,
  min = 0,
  max = 100,
  step = 1,
  onChange,
  unit,
  showValue = true,
  label,
  style,
  ...rest
}) {
  const pct = max === min ? 0 : (value - min) / (max - min) * 100;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 8,
      ...style
    }
  }, (label || showValue) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'baseline',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-body)',
      fontSize: 'var(--fs-body-s)',
      color: 'var(--text-body)'
    }
  }, label), showValue ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-body)',
      fontWeight: 'var(--fw-semibold)',
      color: 'var(--text-accent)',
      fontVariantNumeric: 'tabular-nums lining-nums'
    }
  }, value, unit ? '\u00A0' + unit : '') : null), /*#__PURE__*/React.createElement("input", _extends({
    type: "range",
    value: value,
    min: min,
    max: max,
    step: step,
    onChange: onChange
  }, rest, {
    style: {
      WebkitAppearance: 'none',
      appearance: 'none',
      width: '100%',
      height: 6,
      borderRadius: 'var(--radius-pill)',
      background: 'linear-gradient(to right, var(--clay-500) 0%, var(--clay-500) ' + pct + '%, var(--paper-300) ' + pct + '%, var(--paper-300) 100%)',
      outline: 'none',
      cursor: 'pointer'
    }
  })));
}
Object.assign(__ds_scope, { Slider });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Slider.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Interrupteur pour une bascule immediate. */
function Switch({
  checked,
  onChange,
  label,
  disabled,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 12,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    checked: checked,
    onChange: onChange,
    disabled: disabled
  }, rest, {
    style: {
      position: 'absolute',
      opacity: 0,
      width: 1,
      height: 1
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      width: 46,
      height: 27,
      borderRadius: 'var(--radius-pill)',
      flex: '0 0 auto',
      background: checked ? 'var(--clay-500)' : 'var(--warm-200)',
      transition: 'background-color var(--dur-base) var(--ease-standard)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 3,
      left: checked ? 22 : 3,
      width: 21,
      height: 21,
      borderRadius: 'var(--radius-pill)',
      background: 'var(--paper-50)',
      boxShadow: 'var(--shadow-1)',
      transition: 'left var(--dur-base) var(--ease-out-soft)'
    }
  })), label ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-body)',
      fontSize: 'var(--fs-body-s)',
      color: 'var(--text-title)'
    }
  }, label) : null);
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/forms/TextInput.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const H = {
  s: 'var(--control-h-s)',
  m: 'var(--control-h-m)',
  l: 'var(--control-h-l)'
};

/** Champ texte a une ligne. */
function TextInput({
  size = 'm',
  icon,
  invalid,
  disabled,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center'
    }
  }, icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 18,
    color: "var(--text-muted)",
    style: {
      position: 'absolute',
      left: 14
    }
  }) : null, /*#__PURE__*/React.createElement("input", _extends({
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false)
  }, rest, {
    style: {
      width: '100%',
      height: H[size],
      padding: icon ? '0 16px 0 42px' : '0 16px',
      font: 'var(--type-body)',
      color: 'var(--text-title)',
      background: disabled ? 'var(--paper-200)' : 'var(--surface-card)',
      border: '1px solid ' + (invalid ? 'var(--brick-500)' : focus ? 'var(--clay-400)' : 'var(--border-default)'),
      borderRadius: 'var(--radius-field)',
      boxShadow: focus ? 'var(--ring-focus)' : 'var(--shadow-inset-field)',
      outline: 'none',
      transition: 'var(--transition-control)',
      ...style
    }
  })));
}
Object.assign(__ds_scope, { TextInput });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/TextInput.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Stepper.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Progression numerotee du parcours de saisie. */
function Stepper({
  steps = [],
  current = 0,
  onStepClick,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("ol", _extends({}, rest, {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 0,
      margin: 0,
      padding: 0,
      listStyle: 'none',
      ...style
    }
  }), steps.map(function (label, i) {
    const done = i < current;
    const active = i === current;
    return /*#__PURE__*/React.createElement("li", {
      key: label,
      style: {
        display: 'flex',
        alignItems: 'center',
        flex: i === steps.length - 1 ? '0 0 auto' : 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("button", {
      type: "button",
      onClick: function () {
        if (onStepClick) onStepClick(i);
      },
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 10,
        background: 'none',
        border: 'none',
        padding: 0,
        cursor: onStepClick ? 'pointer' : 'default',
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flex: '0 0 auto',
        width: 30,
        height: 30,
        borderRadius: '50%',
        background: done ? 'var(--clay-500)' : active ? 'var(--surface-card)' : 'var(--paper-200)',
        border: '1px solid ' + (active ? 'var(--clay-500)' : done ? 'var(--clay-500)' : 'var(--border-default)'),
        color: done ? 'var(--text-inverse)' : active ? 'var(--text-accent)' : 'var(--text-muted)',
        font: 'var(--type-caption)',
        fontWeight: 'var(--fw-semibold)',
        transition: 'var(--transition-control)'
      }
    }, done ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: "check",
      size: 15
    }) : i + 1), /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--type-body)',
        fontSize: 'var(--fs-body-s)',
        fontWeight: active ? 'var(--fw-semibold)' : 'var(--fw-regular)',
        color: active ? 'var(--text-title)' : 'var(--text-muted)',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis'
      }
    }, label)), i < steps.length - 1 ? /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        height: 1,
        background: 'var(--border-default)',
        margin: '0 16px',
        minWidth: 16
      }
    }) : null);
  }));
}
Object.assign(__ds_scope, { Stepper });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Stepper.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Onglets soulignes pour changer de vue. */
function Tabs({
  items = [],
  value,
  onChange,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "tablist"
  }, rest, {
    style: {
      display: 'flex',
      gap: 28,
      borderBottom: '1px solid var(--border-default)',
      ...style
    }
  }), items.map(function (it) {
    const active = it.value === value;
    return /*#__PURE__*/React.createElement("button", {
      key: it.value,
      type: "button",
      role: "tab",
      "aria-selected": active,
      onClick: function () {
        if (onChange) onChange(it.value);
      },
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 8,
        padding: '0 2px 14px',
        background: 'none',
        border: 'none',
        cursor: 'pointer',
        borderBottom: '2px solid ' + (active ? 'var(--clay-500)' : 'transparent'),
        marginBottom: -1,
        color: active ? 'var(--text-title)' : 'var(--text-muted)',
        font: 'var(--type-body)',
        fontWeight: active ? 'var(--fw-semibold)' : 'var(--fw-medium)',
        transition: 'var(--transition-control)'
      }
    }, it.icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: it.icon,
      size: 17
    }) : null, it.label);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/Chrome.jsx
try { (() => {
const {
  Button,
  IconButton,
  Icon
} = window.PerronDesignSystem_49e698;
const NAV = [{
  key: 'landing',
  label: 'Le simulateur'
}, {
  key: 'simulateur',
  label: 'Faire une simulation'
}, {
  key: 'resultats',
  label: 'Exemple de résultat'
}];
function Logotype({
  size = 22,
  inverse
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: size,
      letterSpacing: 'var(--ls-display)',
      color: inverse ? 'var(--paper-50)' : 'var(--text-title)',
      whiteSpace: 'nowrap'
    }
  }, "Acheter ", /*#__PURE__*/React.createElement("i", {
    style: {
      color: inverse ? 'var(--clay-200)' : 'var(--clay-500)'
    }
  }, "ou"), " louer");
}
function SiteHeader({
  screen,
  onNavigate
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 30,
      background: 'rgba(251,247,240,.88)',
      backdropFilter: 'blur(10px)',
      borderBottom: '1px solid var(--border-hairline)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '0 var(--gutter-desktop)',
      height: 72,
      display: 'flex',
      alignItems: 'center',
      gap: 32
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNavigate('landing');
    },
    style: {
      textDecoration: 'none'
    }
  }, /*#__PURE__*/React.createElement(Logotype, null)), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 26,
      marginLeft: 12
    }
  }, NAV.map(n => /*#__PURE__*/React.createElement("a", {
    key: n.key,
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNavigate(n.key);
    },
    style: {
      textDecoration: 'none',
      font: 'var(--type-body)',
      fontSize: 'var(--fs-body-s)',
      fontWeight: screen === n.key ? 'var(--fw-semibold)' : 'var(--fw-regular)',
      color: screen === n.key ? 'var(--text-title)' : 'var(--text-body)'
    }
  }, n.label))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "user-round",
    label: "Mon espace",
    variant: "ghost",
    size: "s"
  }), /*#__PURE__*/React.createElement(Button, {
    size: "s",
    iconRight: "arrow-right",
    onClick: () => onNavigate('simulateur')
  }, "Lancer une simulation"))));
}
function SiteFooter() {
  const cols = [{
    t: 'Le produit',
    l: ['Simulateur', 'Méthode de calcul', 'Hypothèses par défaut', 'Enregistrer une simulation']
  }, {
    t: 'Comprendre',
    l: ['Frais de notaire ancien / neuf', 'Fiscalité des plus-values', 'Patrimoine net immobilier', 'Rendement brut et net']
  }, {
    t: 'À propos',
    l: ['Qui sommes-nous', 'Contact', 'Mentions légales', 'Confidentialité']
  }];
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: 'var(--surface-inverse)',
      color: 'var(--paper-200)',
      position: 'relative',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      inset: 0,
      backgroundImage: 'url(../../assets/grain.png)',
      opacity: 0.3,
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '56px var(--gutter-desktop) 32px',
      display: 'grid',
      gridTemplateColumns: '1.4fr repeat(3, 1fr)',
      gap: 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 12,
      alignContent: 'start'
    }
  }, /*#__PURE__*/React.createElement(Logotype, {
    inverse: true
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body)',
      fontSize: 'var(--fs-body-s)',
      color: 'var(--warm-200)',
      maxWidth: 260
    }
  }, "Un simulateur qui compare l'achat de votre r\xE9sidence principale au fait de rester locataire, \xE0 budget identique.")), cols.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.t,
    style: {
      display: 'grid',
      gap: 10,
      alignContent: 'start'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-eyebrow)',
      textTransform: 'uppercase',
      letterSpacing: 'var(--ls-caps)',
      color: 'var(--clay-200)'
    }
  }, c.t), c.l.map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: "#",
    onClick: e => e.preventDefault(),
    style: {
      font: 'var(--type-body)',
      fontSize: 'var(--fs-body-s)',
      color: 'var(--paper-200)',
      textDecoration: 'none'
    }
  }, l))))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '20px var(--gutter-desktop) 40px',
      borderTop: '1px solid rgba(251,247,240,.14)',
      display: 'flex',
      justifyContent: 'space-between',
      font: 'var(--type-caption)',
      fontWeight: 'var(--fw-regular)',
      color: 'var(--warm-200)'
    }
  }, /*#__PURE__*/React.createElement("span", null, "\xA9 2026 \u2014 Les r\xE9sultats sont des projections, pas un conseil en investissement."), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      gap: 8,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "lock",
    size: 14
  }), " Aucune donn\xE9e revendue")));
}
Object.assign(window, {
  SiteHeader,
  SiteFooter,
  Logotype
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/Chrome.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/Landing.jsx
try { (() => {
const {
  Button,
  Card,
  Badge,
  Callout,
  Icon,
  StatTile,
  ComparisonBar,
  Legend
} = window.PerronDesignSystem_49e698;
const STEPS = [{
  icon: 'house',
  t: 'Décrivez le bien',
  d: "Prix, ville, ancien ou neuf, apport et durée de détention envisagée."
}, {
  icon: 'wallet',
  t: 'Fixez votre enveloppe',
  d: "Un même budget mensuel des deux côtés : mensualité et charges, ou loyer et épargne."
}, {
  icon: 'scale',
  t: "Comparez net d'impôt",
  d: 'Patrimoine net année par année, des deux côtés, une fois la fiscalité déduite.'
}];
function Landing({
  onNavigate
}) {
  return /*#__PURE__*/React.createElement("main", null, /*#__PURE__*/React.createElement("section", {
    style: {
      position: 'relative',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '72px var(--gutter-desktop) 88px',
      display: 'grid',
      gridTemplateColumns: '1.05fr .95fr',
      gap: 56,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 22,
      justifyItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "accent",
    icon: "scale"
  }, "Comparaison \xE0 budget identique"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 'var(--fs-display-xl)',
      maxWidth: 620
    }
  }, "Acheter ou louer", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--clay-500)'
    }
  }, "\u202F?"), " ", /*#__PURE__*/React.createElement("i", {
    style: {
      color: 'var(--text-muted)'
    }
  }, "Chiffres \xE0 l'appui.")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--fs-body-l)',
      color: 'var(--text-body)',
      maxWidth: 520
    }
  }, "Le simulateur r\xE9partit la m\xEAme enveloppe mensuelle sur deux trajectoires \u2014 devenir propri\xE9taire, ou rester locataire et investir la diff\xE9rence \u2014 puis compare votre patrimoine net \xE0 la date que vous choisissez."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "l",
    iconRight: "arrow-right",
    onClick: () => onNavigate('simulateur')
  }, "Faire ma simulation"), /*#__PURE__*/React.createElement(Button, {
    size: "l",
    variant: "secondary",
    iconLeft: "file-text",
    onClick: () => onNavigate('resultats')
  }, "Voir un exemple")), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      fontWeight: 'var(--fw-regular)',
      color: 'var(--text-muted)'
    }
  }, "Gratuit, sans compte \u2014 4 minutes de saisie.")), /*#__PURE__*/React.createElement(Card, {
    padding: 0,
    elevation: 3,
    style: {
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      padding: '22px 26px',
      background: 'var(--clay-500)',
      color: 'var(--paper-50)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      inset: 0,
      backgroundImage: 'url(../../assets/grain.png)',
      opacity: 0.3
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'baseline'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-eyebrow)',
      textTransform: 'uppercase',
      letterSpacing: 'var(--ls-caps)',
      color: 'var(--clay-100)'
    }
  }, "EXEMPLE \u2014 LYON 3E, 320 000 \u20AC"), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)'
    }
  }, "12 ans")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--fs-display-s)',
      marginTop: 8
    }
  }, "Acheter laisse 38 400 \u20AC de plus")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 26,
      display: 'grid',
      gap: 22
    }
  }, /*#__PURE__*/React.createElement(ComparisonBar, {
    items: [{
      label: 'Patrimoine net — achat',
      value: 412800
    }, {
      label: 'Patrimoine net — location + épargne',
      value: 374400
    }],
    formatValue: v => v.toLocaleString('fr-FR') + ' €'
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(StatTile, {
    size: "s",
    label: "Enveloppe mensuelle",
    value: "1 850",
    unit: "\u20AC",
    icon: "wallet"
  }), /*#__PURE__*/React.createElement(StatTile, {
    size: "s",
    label: "Point de bascule",
    value: "7,2",
    unit: "ans",
    icon: "clock",
    tone: "buy"
  })))))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--surface-sunken)',
      borderTop: '1px solid var(--border-hairline)',
      borderBottom: '1px solid var(--border-hairline)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: 'var(--section-y-desktop) var(--gutter-desktop)',
      display: 'grid',
      gap: 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 12,
      maxWidth: 'var(--container-prose)'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 'var(--fs-display-m)'
    }
  }, "Trois \xE9tapes, une seule hypoth\xE8se forte"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--fs-body-l)',
      color: 'var(--text-body)'
    }
  }, "Les deux trajectoires consomment exactement le m\xEAme budget. Ce qui n'est pas d\xE9pens\xE9 en logement est investi en bourse, au m\xEAme rendement, des deux c\xF4t\xE9s.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      gap: 20
    }
  }, STEPS.map((s, i) => /*#__PURE__*/React.createElement(Card, {
    key: s.t,
    elevation: 1,
    padding: 26
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: 44,
      height: 44,
      borderRadius: 'var(--radius-m)',
      background: 'var(--clay-50)',
      border: '1px solid var(--clay-100)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: s.icon,
    size: 22,
    color: "var(--clay-600)"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-eyebrow)',
      textTransform: 'uppercase',
      letterSpacing: 'var(--ls-caps)',
      color: 'var(--text-muted)'
    }
  }, "\xC9TAPE ", i + 1)), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 'var(--fs-title-s)',
      marginBottom: 8
    }
  }, s.t), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--fs-body-s)',
      color: 'var(--text-body)'
    }
  }, s.d)))))), /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: 'var(--section-y-desktop) var(--gutter-desktop)',
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 56,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 'var(--fs-display-m)'
    }
  }, "Ce que le calcul prend en compte"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--fs-body-m)',
      color: 'var(--text-body)'
    }
  }, "Frais de notaire diff\xE9renci\xE9s ancien et neuf, assurance emprunteur, taxe fonci\xE8re, charges de copropri\xE9t\xE9, entretien, et le capital restant d\xFB d\xE9duit de la valeur du bien. C\xF4t\xE9 location, le loyer, son indexation, et l'\xE9pargne plac\xE9e mois apr\xE8s mois."), /*#__PURE__*/React.createElement(Callout, {
    tone: "info",
    title: "Tout est net d'imp\xF4t, des deux c\xF4t\xE9s"
  }, "Le rendement de la bourse se saisit en brut. La fiscalit\xE9 de sortie est appliqu\xE9e au d\xE9nouement, avec un taux que vous pouvez modifier \u2014 31,4 % par d\xE9faut, le taux d'un compte-titres."), /*#__PURE__*/React.createElement(Callout, {
    tone: "warning",
    title: "Une projection, pas une promesse"
  }, "Personne ne conna\xEEt le rendement des march\xE9s ni l'\xE9volution des prix immobiliers sur douze ans. Faites varier les hypoth\xE8ses : c'est l'\xE9cart entre les sc\xE9narios qui est instructif, pas le chiffre unique.")), /*#__PURE__*/React.createElement(Card, {
    padding: 28,
    elevation: 2
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(Legend, {
    items: [{
      label: 'Achat',
      color: 'var(--data-buy)'
    }, {
      label: 'Location + épargne',
      color: 'var(--data-rent)'
    }]
  }), [['Mensualité de crédit', '1 420 €', '—'], ['Charges et entretien', '310 €', '—'], ['Loyer', '—', '1 180 €'], ['Épargne investie', '120 €', '670 €'], ['Enveloppe totale', '1 850 €', '1 850 €']].map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: r[0],
    style: {
      display: 'grid',
      gridTemplateColumns: '1.4fr .8fr .8fr',
      gap: 12,
      paddingBottom: 12,
      borderBottom: i === 4 ? 'none' : '1px solid var(--border-hairline)',
      fontWeight: i === 4 ? 'var(--fw-semibold)' : 'var(--fw-regular)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--fs-body-s)',
      color: i === 4 ? 'var(--text-title)' : 'var(--text-body)'
    }
  }, r[0]), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--fs-body-s)',
      textAlign: 'right',
      color: 'var(--clay-600)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, r[1]), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--fs-body-s)',
      textAlign: 'right',
      color: 'var(--olive-600)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, r[2]))))))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--clay-500)',
      position: 'relative',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      inset: 0,
      backgroundImage: 'url(../../assets/grain.png)',
      opacity: 0.28
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      maxWidth: 'var(--container-prose)',
      margin: '0 auto',
      padding: '80px var(--gutter-desktop)',
      textAlign: 'center',
      display: 'grid',
      gap: 20,
      justifyItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      color: 'var(--paper-50)',
      fontSize: 'var(--fs-display-m)'
    }
  }, "Votre situation n'est pas une moyenne nationale"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--fs-body-l)',
      color: 'var(--clay-100)'
    }
  }, "Quatre minutes de saisie, et vous saurez \xE0 partir de quelle ann\xE9e l'achat devient gagnant dans votre cas."), /*#__PURE__*/React.createElement(Button, {
    size: "l",
    variant: "secondary",
    iconRight: "arrow-right",
    onClick: () => onNavigate('simulateur')
  }, "Faire ma simulation"))));
}
Object.assign(window, {
  Landing
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/Landing.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/Resultats.jsx
try { (() => {
const {
  Card,
  Button,
  IconButton,
  Badge,
  Tabs,
  StatTile,
  DeltaValue,
  ComparisonBar,
  Legend,
  DataTable,
  Callout,
  Dialog,
  Field,
  TextInput,
  Switch,
  Icon
} = window.PerronDesignSystem_49e698;
const ROWS = [{
  an: '2027',
  achat: '58 200 €',
  loc: '61 900 €',
  ecart: '−3 700 €'
}, {
  an: '2029',
  achat: '118 400 €',
  loc: '124 300 €',
  ecart: '−5 900 €'
}, {
  an: '2031',
  achat: '186 900 €',
  loc: '188 100 €',
  ecart: '−1 200 €'
}, {
  an: '2033',
  achat: '248 700 €',
  loc: '243 500 €',
  ecart: '+5 200 €'
}, {
  an: '2035',
  achat: '318 200 €',
  loc: '302 800 €',
  ecart: '+15 400 €'
}, {
  an: '2038',
  achat: '412 800 €',
  loc: '374 400 €',
  ecart: '+38 400 €'
}];
function Chart({
  height = 320
}) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!ref.current || !window.Chart) return;
    const years = Array.from({
      length: 13
    }, (_, i) => 2026 + i);
    const buy = [0, 22, 58, 88, 118, 152, 187, 217, 249, 282, 318, 364, 413].map(v => v * 1000);
    const rent = [0, 31, 62, 93, 124, 156, 188, 216, 244, 273, 303, 338, 374].map(v => v * 1000);
    const css = n => getComputedStyle(document.body).getPropertyValue(n).trim();
    const c = new window.Chart(ref.current, {
      type: 'line',
      data: {
        labels: years,
        datasets: [{
          label: 'Achat',
          data: buy,
          borderColor: css('--data-buy'),
          backgroundColor: 'rgba(168,102,63,.10)',
          fill: true,
          tension: 0.32,
          borderWidth: 2.5,
          pointRadius: 0
        }, {
          label: 'Location',
          data: rent,
          borderColor: css('--data-rent'),
          backgroundColor: 'rgba(110,127,88,.10)',
          fill: true,
          tension: 0.32,
          borderWidth: 2.5,
          pointRadius: 0,
          borderDash: [5, 4]
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false
          },
          tooltip: {
            backgroundColor: css('--warm-700'),
            padding: 12,
            cornerRadius: 10,
            displayColors: false
          }
        },
        scales: {
          x: {
            grid: {
              display: false
            },
            border: {
              color: css('--border-default')
            },
            ticks: {
              color: css('--text-muted'),
              font: {
                family: 'Geist',
                size: 12
              }
            }
          },
          y: {
            grid: {
              color: css('--border-hairline')
            },
            border: {
              display: false
            },
            ticks: {
              color: css('--text-muted'),
              font: {
                family: 'Geist',
                size: 12
              },
              callback: v => v / 1000 + ' k€'
            }
          }
        }
      }
    });
    return () => c.destroy();
  }, []);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height
    }
  }, /*#__PURE__*/React.createElement("canvas", {
    ref: ref
  }));
}
function Resultats({
  onNavigate
}) {
  const [vue, setVue] = React.useState('graph');
  const [save, setSave] = React.useState(false);
  const [net, setNet] = React.useState(true);
  return /*#__PURE__*/React.createElement("main", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--surface-sunken)',
      borderBottom: '1px solid var(--border-hairline)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '48px var(--gutter-desktop) 40px',
      display: 'grid',
      gap: 26
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-start',
      gap: 24,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 14,
      maxWidth: 720
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "accent",
    icon: "map-pin"
  }, "Lyon 3e \xB7 320 000 \u20AC \xB7 ancien \xB7 12 ans"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 'var(--fs-display-l)'
    }
  }, "Sur 12 ans, acheter vous laisse ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--clay-500)'
    }
  }, "38 400 \u20AC"), " de plus"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--fs-body-l)',
      color: 'var(--text-body)'
    }
  }, "\xC0 enveloppe identique de 1 850 \u20AC par mois, net d'imp\xF4t des deux c\xF4t\xE9s. L'achat passe devant la location \xE0 partir de la septi\xE8me ann\xE9e.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "share-2",
    label: "Partager"
  }), /*#__PURE__*/React.createElement(IconButton, {
    icon: "download",
    label: "T\xE9l\xE9charger en PDF"
  }), /*#__PURE__*/React.createElement(Button, {
    iconLeft: "bookmark",
    onClick: () => setSave(true)
  }, "Enregistrer"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(StatTile, {
    label: "Patrimoine net \u2014 achat",
    value: "412 800",
    unit: "\u20AC",
    tone: "buy",
    icon: "house"
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "Patrimoine net \u2014 location",
    value: "374 400",
    unit: "\u20AC",
    tone: "rent",
    icon: "key-round"
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "\xC9cart final",
    value: "+38 400",
    unit: "\u20AC",
    tone: "positive",
    icon: "scale"
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "Point de bascule",
    value: "7,2",
    unit: "ans",
    icon: "clock",
    note: "Avant cette date, louer est gagnant"
  })))), /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '36px var(--gutter-desktop) 88px',
      display: 'grid',
      gridTemplateColumns: '1.6fr 1fr',
      gap: 28,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: 26
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 20,
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    value: vue,
    onChange: setVue,
    items: [{
      value: 'graph',
      label: 'Graphique',
      icon: 'chart-line'
    }, {
      value: 'table',
      label: 'Année par année',
      icon: 'file-text'
    }, {
      value: 'hyp',
      label: 'Hypothèses',
      icon: 'sliders-horizontal'
    }],
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(Switch, {
    checked: net,
    onChange: () => setNet(!net),
    label: "Net d'imp\xF4t"
  })), vue === 'graph' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(Legend, {
    items: [{
      label: 'Achat',
      color: 'var(--data-buy)',
      value: '412 800 €'
    }, {
      label: 'Location + épargne',
      color: 'var(--data-rent)',
      value: '374 400 €'
    }]
  }), /*#__PURE__*/React.createElement(Chart, null), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-caption)',
      fontWeight: 'var(--fw-regular)',
      color: 'var(--text-muted)'
    }
  }, "Patrimoine net cumul\xE9, en euros courants. C\xF4t\xE9 achat : valeur du bien moins capital restant d\xFB, plus l'\xE9pargne plac\xE9e.")), vue === 'table' && /*#__PURE__*/React.createElement(DataTable, {
    columns: [{
      key: 'an',
      label: 'Année'
    }, {
      key: 'achat',
      label: 'Achat',
      align: 'right',
      emphasis: true
    }, {
      key: 'loc',
      label: 'Location + épargne',
      align: 'right'
    }, {
      key: 'ecart',
      label: 'Écart',
      align: 'right'
    }],
    rows: ROWS
  }), vue === 'hyp' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 14
    }
  }, [['Rendement bourse (brut)', '5,5 % / an'], ['Fiscalité de sortie', '31,4 % — compte-titres'], ['Revalorisation du bien', '1,5 % / an'], ['Indexation des loyers', '1,9 % / an'], ['Frais de notaire', '7,8 % — ancien'], ['Taux nominal du crédit', '3,35 % sur 20 ans'], ['Assurance emprunteur', '0,34 % du capital initial']].map(r => /*#__PURE__*/React.createElement("div", {
    key: r[0],
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      paddingBottom: 12,
      borderBottom: '1px solid var(--border-hairline)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--fs-body-s)',
      color: 'var(--text-body)'
    }
  }, r[0]), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--fs-body-s)',
      fontWeight: 'var(--fw-semibold)',
      color: 'var(--text-title)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, r[1]))), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    iconLeft: "pencil",
    onClick: () => onNavigate('simulateur'),
    style: {
      justifySelf: 'start',
      marginTop: 4
    }
  }, "Modifier les hypoth\xE8ses"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Card, {
    title: "O\xF9 part l'argent",
    padding: 24
  }, /*#__PURE__*/React.createElement(ComparisonBar, {
    items: [{
      label: 'Achat — intérêts et frais perdus',
      value: 96400
    }, {
      label: 'Location — loyers versés',
      value: 178200
    }],
    formatValue: v => v.toLocaleString('fr-FR') + ' €'
  })), /*#__PURE__*/React.createElement(Card, {
    tone: "accent",
    padding: 24,
    elevation: 1
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      font: 'var(--type-eyebrow)',
      textTransform: 'uppercase',
      letterSpacing: 'var(--ls-caps)',
      color: 'var(--clay-700)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "lightbulb",
    size: 15
  }), " CE QUI CHANGE TOUT"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--fs-body-s)',
      color: 'var(--text-body)'
    }
  }, "Avec un rendement boursier de 7 % au lieu de 5,5 %, la location repasse devant : ", /*#__PURE__*/React.createElement(DeltaValue, {
    value: "\u221214 200",
    unit: "\u20AC",
    size: "s"
  }), " pour l'achat."), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "s",
    iconRight: "arrow-right",
    onClick: () => onNavigate('simulateur'),
    style: {
      justifySelf: 'start',
      paddingLeft: 0
    }
  }, "Tester ce sc\xE9nario"))), /*#__PURE__*/React.createElement(Callout, {
    tone: "warning",
    title: "Revente avant 7 ans"
  }, "Les frais de notaire et les int\xE9r\xEAts des premi\xE8res ann\xE9es ne sont pas amortis : sur un horizon court, rester locataire reste plus favorable."))), save && /*#__PURE__*/React.createElement(Dialog, {
    title: "Enregistrer cette simulation",
    description: "Vous la retrouverez dans votre espace, avec toutes ses hypoth\xE8ses.",
    onClose: () => setSave(false),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "quiet",
      onClick: () => setSave(false)
    }, "Annuler"), /*#__PURE__*/React.createElement(Button, {
      onClick: () => setSave(false)
    }, "Enregistrer"))
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Nom de la simulation"
  }, /*#__PURE__*/React.createElement(TextInput, {
    defaultValue: "Lyon 3e \u2014 320 000 \u20AC \u2014 12 ans"
  }))));
}
Object.assign(window, {
  Resultats
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/Resultats.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/Simulateur.jsx
try { (() => {
const {
  Card,
  Button,
  Badge,
  Field,
  TextInput,
  NumberField,
  Select,
  SegmentedControl,
  Slider,
  Checkbox,
  Switch,
  Stepper,
  Callout,
  StatTile,
  Icon,
  Tooltip
} = window.PerronDesignSystem_49e698;
const STEP_LABELS = ['Votre projet', 'Financement', 'Hypothèses', 'Résultat'];
function Simulateur({
  onNavigate
}) {
  const [step, setStep] = React.useState(1);
  const [type, setType] = React.useState('ancien');
  const [duree, setDuree] = React.useState(12);
  const [rendement, setRendement] = React.useState(5.5);
  const [assurance, setAssurance] = React.useState(true);
  const [indexation, setIndexation] = React.useState(true);
  return /*#__PURE__*/React.createElement("main", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '40px var(--gutter-desktop) 88px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 10,
      marginBottom: 32
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 'var(--fs-display-m)'
    }
  }, "Votre simulation"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--fs-body-m)',
      color: 'var(--text-body)',
      maxWidth: 'var(--container-prose)'
    }
  }, "Les valeurs par d\xE9faut correspondent au march\xE9 fran\xE7ais en 2026. Modifiez celles que vous connaissez, laissez les autres.")), /*#__PURE__*/React.createElement(Card, {
    padding: 20,
    elevation: 1,
    style: {
      marginBottom: 28
    }
  }, /*#__PURE__*/React.createElement(Stepper, {
    steps: STEP_LABELS,
    current: step,
    onStepClick: setStep
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.55fr 1fr',
      gap: 28,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(Card, {
    title: "Le bien",
    padding: 26
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Prix du bien",
    hint: "Hors frais de notaire"
  }, /*#__PURE__*/React.createElement(NumberField, {
    defaultValue: "320 000",
    unit: "\u20AC"
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Ville"
  }, /*#__PURE__*/React.createElement(TextInput, {
    defaultValue: "Lyon 3e",
    icon: "map-pin"
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Type de bien",
    hint: "Les frais de notaire diff\xE8rent"
  }, /*#__PURE__*/React.createElement(SegmentedControl, {
    value: type,
    onChange: setType,
    options: [{
      value: 'ancien',
      label: 'Ancien — 7,8 %'
    }, {
      value: 'neuf',
      label: 'Neuf — 2,9 %'
    }]
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Taxe fonci\xE8re annuelle"
  }, /*#__PURE__*/React.createElement(NumberField, {
    defaultValue: "1 240",
    unit: "\u20AC"
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Charges de copropri\xE9t\xE9"
  }, /*#__PURE__*/React.createElement(NumberField, {
    defaultValue: "145",
    unit: "\u20AC/mois"
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Entretien annuel",
    hint: "0,8 % de la valeur par d\xE9faut"
  }, /*#__PURE__*/React.createElement(NumberField, {
    defaultValue: "2 560",
    unit: "\u20AC"
  })))), /*#__PURE__*/React.createElement(Card, {
    title: "Le financement",
    padding: 26
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Apport",
    hint: "Frais de notaire inclus"
  }, /*#__PURE__*/React.createElement(NumberField, {
    defaultValue: "60 000",
    unit: "\u20AC"
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Dur\xE9e du cr\xE9dit"
  }, /*#__PURE__*/React.createElement(Select, {
    defaultValue: "20",
    options: [{
      value: '15',
      label: '15 ans'
    }, {
      value: '20',
      label: '20 ans'
    }, {
      value: '25',
      label: '25 ans'
    }]
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Taux nominal"
  }, /*#__PURE__*/React.createElement(NumberField, {
    defaultValue: "3,35",
    unit: "%"
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Assurance emprunteur"
  }, /*#__PURE__*/React.createElement(NumberField, {
    defaultValue: "0,34",
    unit: "%",
    disabled: !assurance
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: '1 / -1',
      display: 'grid',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Checkbox, {
    checked: assurance,
    onChange: () => setAssurance(!assurance),
    label: "Inclure l'assurance emprunteur",
    description: "Calcul\xE9e sur le capital initial, comme la plupart des offres bancaires."
  }), /*#__PURE__*/React.createElement(Checkbox, {
    checked: indexation,
    onChange: () => setIndexation(!indexation),
    label: "Indexer le loyer sur l'inflation",
    description: "IRL estim\xE9 \xE0 1,9 % par an."
  })))), /*#__PURE__*/React.createElement(Card, {
    title: "Les hypoth\xE8ses de march\xE9",
    padding: 26,
    action: /*#__PURE__*/React.createElement(Badge, {
      tone: "warning",
      icon: "circle-alert"
    }, "\xC0 faire varier")
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 22
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 22
    }
  }, /*#__PURE__*/React.createElement(Slider, {
    label: "Dur\xE9e de d\xE9tention",
    value: duree,
    min: 1,
    max: 30,
    unit: "ans",
    onChange: e => setDuree(+e.target.value)
  }), /*#__PURE__*/React.createElement(Slider, {
    label: "Rendement bourse (brut)",
    value: rendement,
    min: 0,
    max: 12,
    step: 0.1,
    unit: "%",
    onChange: e => setRendement(+e.target.value)
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Revalorisation du bien",
    hint: "Par an, en euros courants"
  }, /*#__PURE__*/React.createElement(NumberField, {
    defaultValue: "1,5",
    unit: "%"
  })), /*#__PURE__*/React.createElement(Field, {
    label: /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6
      }
    }, "Fiscalit\xE9 de sortie ", /*#__PURE__*/React.createElement(Tooltip, {
      content: "Taux appliqu\xE9 aux plus-values boursi\xE8res au d\xE9nouement. 31,4 % = flat tax d'un compte-titres."
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "info",
      size: 14,
      color: "var(--text-muted)"
    })))
  }, /*#__PURE__*/React.createElement(Select, {
    defaultValue: "cto",
    options: [{
      value: 'cto',
      label: 'Compte-titres — 31,4 %'
    }, {
      value: 'pea',
      label: 'PEA — 17,2 %'
    }, {
      value: 'av',
      label: 'Assurance-vie — 24,7 %'
    }, {
      value: 'custom',
      label: 'Taux personnalisé'
    }]
  }))), /*#__PURE__*/React.createElement(Callout, {
    tone: "tip",
    title: "Le rendement se saisit en brut"
  }, "L'imp\xF4t est retir\xE9 une seule fois, \xE0 la sortie, pour que les deux trajectoires soient compar\xE9es nettes.")))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'sticky',
      top: 96,
      display: 'grid',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Card, {
    tone: "sunken",
    padding: 22,
    elevation: 0,
    title: "Enveloppe mensuelle"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(NumberField, {
    defaultValue: "1 850",
    unit: "\u20AC/mois",
    size: "l"
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-caption)',
      fontWeight: 'var(--fw-regular)',
      color: 'var(--text-muted)'
    }
  }, "Le m\xEAme montant des deux c\xF4t\xE9s. C\xF4t\xE9 achat : mensualit\xE9, assurance, charges, entretien, taxe fonci\xE8re. C\xF4t\xE9 location : loyer, puis \xE9pargne du reste."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 10,
      paddingTop: 4
    }
  }, [['Achat — logement', '1 730 €', 'var(--data-buy)'], ['Achat — épargne', '120 €', 'var(--data-buy)'], ['Location — loyer', '1 180 €', 'var(--data-rent)'], ['Location — épargne', '670 €', 'var(--data-rent)']].map(r => /*#__PURE__*/React.createElement("div", {
    key: r[0],
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      fontSize: 'var(--fs-body-s)',
      color: 'var(--text-body)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: '50%',
      background: r[2]
    }
  }), r[0]), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--fs-body-s)',
      fontWeight: 'var(--fw-semibold)',
      color: 'var(--text-title)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, r[1])))))), /*#__PURE__*/React.createElement(StatTile, {
    label: 'Aperçu à ' + duree + ' ans',
    value: '+' + Math.round(3200 * duree).toLocaleString('fr-FR'),
    unit: "\u20AC",
    tone: "positive",
    icon: "scale",
    note: "En faveur de l'achat, net d'imp\xF4t"
  }), /*#__PURE__*/React.createElement(Button, {
    size: "l",
    fullWidth: true,
    iconRight: "arrow-right",
    onClick: () => onNavigate('resultats')
  }, "Voir le r\xE9sultat d\xE9taill\xE9"), /*#__PURE__*/React.createElement(Button, {
    size: "m",
    variant: "quiet",
    fullWidth: true,
    iconLeft: "refresh-ccw"
  }, "Repartir des valeurs par d\xE9faut"))));
}
Object.assign(window, {
  Simulateur
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/Simulateur.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Callout = __ds_scope.Callout;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.ComparisonBar = __ds_scope.ComparisonBar;

__ds_ns.DataTable = __ds_scope.DataTable;

__ds_ns.DeltaValue = __ds_scope.DeltaValue;

__ds_ns.Legend = __ds_scope.Legend;

__ds_ns.StatTile = __ds_scope.StatTile;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Field = __ds_scope.Field;

__ds_ns.NumberField = __ds_scope.NumberField;

__ds_ns.SegmentedControl = __ds_scope.SegmentedControl;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Slider = __ds_scope.Slider;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.TextInput = __ds_scope.TextInput;

__ds_ns.Stepper = __ds_scope.Stepper;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
